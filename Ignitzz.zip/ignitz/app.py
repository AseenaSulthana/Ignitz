from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
from datetime import datetime, timedelta
import jwt
from functools import wraps

app = Flask(__name__)
app.config.from_pyfile('config.py')
db = SQLAlchemy(app)

# Import models after db initialization to avoid circular imports
from models import User, DeveloperProfile, EntrepreneurProfile, Project, ProjectSkill, ProjectBid, SkillEndorsement, Review

# Token required decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Check if token is in cookies
        if 'token' in request.cookies:
            token = request.cookies.get('token')
        
        # Check if token is in headers
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]
        
        if not token:
            flash('Please log in to access this page', 'error')
            return redirect(url_for('login'))
        
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query.filter_by(id=data['user_id']).first()
            
            if not current_user:
                flash('User not found', 'error')
                return redirect(url_for('login'))
                
        except:
            flash('Session expired. Please log in again', 'error')
            return redirect(url_for('login'))
            
        return f(current_user, *args, **kwargs)
    
    return decorated

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.form
        
        user = User.query.filter_by(email=data.get('email')).first()
        
        if not user or not check_password_hash(user.password, data.get('password')):
            flash('Invalid email or password', 'error')
            return render_template('login.html', role=request.args.get('role', 'developer'))
        
        # Generate token
        token = jwt.encode({
            'user_id': user.id,
            'exp': datetime.utcnow() + timedelta(days=1)
        }, app.config['SECRET_KEY'], algorithm="HS256")
        
        # Set token in session
        session['user_id'] = user.id
        session['role'] = user.role
        session['name'] = user.first_name
        
        # Redirect to appropriate dashboard
        response = redirect(url_for(f'{user.role}_dashboard'))
        response.set_cookie('token', token, httponly=True, max_age=86400)  # 1 day
        
        return response
    
    return render_template('login.html', role=request.args.get('role', 'developer'))

@app.route('/register', methods=['POST'])
def register():
    data = request.form
    
    # Check if user already exists
    existing_user = User.query.filter_by(email=data.get('email')).first()
    if existing_user:
        flash('Email already registered', 'error')
        return redirect(url_for('login', role=data.get('role')))
    
    # Create new user
    hashed_password = generate_password_hash(data.get('password'))
    new_user = User(
        email=data.get('email'),
        password=hashed_password,
        first_name=data.get('first_name'),
        last_name=data.get('last_name'),
        role=data.get('role')
    )
    
    db.session.add(new_user)
    db.session.commit()
    
    # Create role-specific profile
    if data.get('role') == 'developer':
        profile = DeveloperProfile(
            user_id=new_user.id,
            skills=data.get('skills', ''),
            qualification=data.get('qualification', '')
        )
    else:
        profile = EntrepreneurProfile(
            user_id=new_user.id,
            organization=data.get('organization', ''),
            startup_domain=data.get('startup_domain', '')
        )
    
    db.session.add(profile)
    db.session.commit()
    
    # Generate token
    token = jwt.encode({
        'user_id': new_user.id,
        'exp': datetime.utcnow() + timedelta(days=1)
    }, app.config['SECRET_KEY'], algorithm="HS256")
    
    # Set token in session
    session['user_id'] = new_user.id
    session['role'] = new_user.role
    session['name'] = new_user.first_name
    
    # Redirect to appropriate dashboard
    response = redirect(url_for(f'{new_user.role}_dashboard'))
    response.set_cookie('token', token, httponly=True, max_age=86400)  # 1 day
    
    return response

@app.route('/logout')
def logout():
    session.clear()
    response = redirect(url_for('index'))
    response.delete_cookie('token')
    return response

@app.route('/developer/dashboard')
@token_required
def developer_dashboard(current_user):
    if current_user.role != 'developer':
        flash('Access denied', 'error')
        return redirect(url_for('index'))
    
    # Get developer profile
    profile = DeveloperProfile.query.filter_by(user_id=current_user.id).first()
    
    # Get active projects
    active_projects = db.session.query(Project, ProjectBid).\
        join(ProjectBid, Project.id == ProjectBid.project_id).\
        filter(ProjectBid.developer_id == current_user.id, ProjectBid.status == 'accepted').all()
    
    # Get skill endorsements
    endorsements = db.session.query(SkillEndorsement.skill, db.func.count(SkillEndorsement.id).label('count')).\
        filter(SkillEndorsement.developer_id == current_user.id).\
        group_by(SkillEndorsement.skill).all()
    
    # Get reviews
    reviews = Review.query.filter_by(reviewee_id=current_user.id).all()
    
    # Get recommended projects based on skills
    if profile and profile.skills:
        skills_list = [skill.strip() for skill in profile.skills.split(',')]
        recommended_projects = db.session.query(Project).\
            join(ProjectSkill, Project.id == ProjectSkill.project_id).\
            filter(ProjectSkill.skill.in_(skills_list), Project.status == 'active').\
            limit(3).all()
    else:
        recommended_projects = []
    
    return render_template(
        'developer/dashboard.html',
        user=current_user,
        profile=profile,
        active_projects=active_projects,
        endorsements=endorsements,
        reviews=reviews,
        recommended_projects=recommended_projects
    )

@app.route('/entrepreneur/dashboard')
@token_required
def entrepreneur_dashboard(current_user):
    if current_user.role != 'entrepreneur':
        flash('Access denied', 'error')
        return redirect(url_for('index'))
    
    # Get entrepreneur profile
    profile = EntrepreneurProfile.query.filter_by(user_id=current_user.id).first()
    
    # Get projects
    projects = Project.query.filter_by(entrepreneur_id=current_user.id).all()
    
    # Get active bids on projects
    active_bids = db.session.query(ProjectBid, Project, User).\
        join(Project, ProjectBid.project_id == Project.id).\
        join(User, ProjectBid.developer_id == User.id).\
        filter(Project.entrepreneur_id == current_user.id, ProjectBid.status == 'pending').all()
    
    # Get top developers (simplified)
    top_developers = User.query.filter_by(role='developer').limit(3).all()
    
    return render_template(
        'entrepreneur/dashboard.html',
        user=current_user,
        profile=profile,
        projects=projects,
        active_bids=active_bids,
        top_developers=top_developers
    )

@app.route('/developer/profile')
@token_required
def developer_profile(current_user):
    if current_user.role != 'developer':
        flash('Access denied', 'error')
        return redirect(url_for('index'))
    
    profile = DeveloperProfile.query.filter_by(user_id=current_user.id).first()
    
    # Get skill endorsements
    endorsements = db.session.query(SkillEndorsement.skill, db.func.count(SkillEndorsement.id).label('count')).\
        filter(SkillEndorsement.developer_id == current_user.id).\
        group_by(SkillEndorsement.skill).all()
    
    # Get projects
    projects = db.session.query(Project, ProjectBid).\
        join(ProjectBid, Project.id == ProjectBid.project_id).\
        filter(ProjectBid.developer_id == current_user.id, ProjectBid.status == 'accepted').all()
    
    return render_template(
        'developer/profile.html',
        user=current_user,
        profile=profile,
        endorsements=endorsements,
        projects=projects
    )

@app.route('/developer/projects')
@token_required
def browse_projects(current_user):
    if current_user.role != 'developer':
        flash('Access denied', 'error')
        return redirect(url_for('index'))
    
    # Get all active projects
    projects = db.session.query(Project, User).\
        join(User, Project.entrepreneur_id == User.id).\
        filter(Project.status == 'active').all()
    
    # Get project skills
    for project, _ in projects:
        project.skills_list = ProjectSkill.query.filter_by(project_id=project.id).all()
    
    return render_template(
        'developer/projects.html',
        user=current_user,
        projects=projects
    )

@app.route('/search')
@token_required
def search(current_user):
    search_type = request.args.get('type', 'developers')
    query = request.args.get('q', '')
    
    if search_type == 'developers':
        results = User.query.filter_by(role='developer').filter(
            (User.first_name.ilike(f'%{query}%')) | 
            (User.last_name.ilike(f'%{query}%'))
        ).all()
        
        # Get profiles for developers
        for developer in results:
            developer.profile = DeveloperProfile.query.filter_by(user_id=developer.id).first()
    else:
        results = db.session.query(Project, User).\
            join(User, Project.entrepreneur_id == User.id).\
            filter(Project.title.ilike(f'%{query}%')).all()
    
    return render_template(
        'search.html',
        user=current_user,
        search_type=search_type,
        query=query,
        results=results
    )

@app.route('/ideathons')
def ideathons():
    # Sample ideathon data (in a real app, this would come from the database)
    ideathons_data = [
        {
            'id': 1,
            'title': 'Fintech Innovation Challenge',
            'description': 'Develop innovative solutions for financial technology challenges facing modern banking systems.',
            'date': 'May 20, 2023',
            'location': 'Virtual',
            'organizer': 'FinEdge',
            'participants': 24,
            'categories': ['Fintech', 'Innovation', 'Banking'],
            'prizes': '$10,000 in cash prizes'
        },
        {
            'id': 2,
            'title': 'Healthcare AI Hackathon',
            'description': 'Create AI-powered solutions to improve patient care and medical diagnostics.',
            'date': 'June 15, 2023',
            'location': 'San Francisco, CA',
            'organizer': 'MediTech Inc.',
            'participants': 32,
            'categories': ['Healthcare', 'AI', 'Machine Learning'],
            'prizes': '$15,000 in cash prizes + mentorship'
        },
        {
            'id': 3,
            'title': 'Sustainable Tech Challenge',
            'description': 'Build technology solutions that address environmental sustainability challenges.',
            'date': 'July 8, 2023',
            'location': 'Virtual',
            'organizer': 'EcoTech Alliance',
            'participants': 18,
            'categories': ['Sustainability', 'CleanTech', 'IoT'],
            'prizes': '$8,000 in cash prizes + incubation opportunity'
        }
    ]
    
    return render_template('ideathons.html', ideathons=ideathons_data)

@app.route('/mission')
def mission():
    return render_template('mission.html')

@app.route('/faq')
def faq():
    return render_template('faq.html')

# API Routes
@app.route('/api/projects', methods=['GET'])
def get_projects():
    projects = Project.query.filter_by(status='active').all()
    result = []
    
    for project in projects:
        entrepreneur = User.query.filter_by(id=project.entrepreneur_id).first()
        skills = ProjectSkill.query.filter_by(project_id=project.id).all()
        
        project_data = {
            'id': project.id,
            'title': project.title,
            'description': project.description,
            'budget_min': float(project.budget_min),
            'budget_max': float(project.budget_max),
            'duration': project.duration,
            'status': project.status,
            'created_at': project.created_at.strftime('%Y-%m-%d'),
            'entrepreneur': {
                'id': entrepreneur.id,
                'name': f"{entrepreneur.first_name} {entrepreneur.last_name}"
            },
            'skills': [skill.skill for skill in skills]
        }
        
        result.append(project_data)
    
    return jsonify(result)

@app.route('/api/projects', methods=['POST'])
@token_required
def create_project(current_user):
    if current_user.role != 'entrepreneur':
        return jsonify({'message': 'Only entrepreneurs can create projects'}), 403
    
    data = request.json
    
    # Create new project
    new_project = Project(
        entrepreneur_id=current_user.id,
        title=data.get('title'),
        description=data.get('description'),
        budget_min=data.get('budget_min'),
        budget_max=data.get('budget_max'),
        duration=data.get('duration'),
        status='active',
        created_at=datetime.utcnow()
    )
    
    db.session.add(new_project)
    db.session.commit()
    
    # Add project skills
    for skill in data.get('skills', []):
        project_skill = ProjectSkill(
            project_id=new_project.id,
            skill=skill
        )
        db.session.add(project_skill)
    
    db.session.commit()
    
    return jsonify({
        'message': 'Project created successfully',
        'project_id': new_project.id
    }), 201

@app.route('/api/endorsements', methods=['POST'])
@token_required
def add_endorsement(current_user):
    data = request.json
    
    # Check if already endorsed
    existing = SkillEndorsement.query.filter_by(
        endorser_id=current_user.id,
        developer_id=data.get('developer_id'),
        skill=data.get('skill')
    ).first()
    
    if existing:
        return jsonify({'message': 'You have already endorsed this skill'}), 409
    
    # Add endorsement
    new_endorsement = SkillEndorsement(
        endorser_id=current_user.id,
        developer_id=data.get('developer_id'),
        skill=data.get('skill'),
        endorsed_at=datetime.utcnow()
    )
    
    db.session.add(new_endorsement)
    db.session.commit()
    
    return jsonify({'message': 'Skill endorsed successfully'}), 201

# Initialize database
@app.before_first_request
def create_tables():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
