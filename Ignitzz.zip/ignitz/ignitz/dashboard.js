document.addEventListener("DOMContentLoaded", () => {
  // Mobile sidebar toggle
  const mobileMenuButton = document.querySelector('.mobile-menu-button');
  const sidebar = document.querySelector('.sidebar');
  
  if (mobileMenuButton && sidebar) {
    mobileMenuButton.addEventListener('click', () => {
      sidebar.classList.toggle('open');
    });
  }
  
  // Close sidebar when clicking outside on mobile
  document.addEventListener('click', (e) => {
    if (window.innerWidth <= 768 && 
        sidebar && 
        sidebar.classList.contains('open') && 
        !sidebar.contains(e.target) && 
        e.target !== mobileMenuButton) {
      sidebar.classList.remove('open');
    }
  });
  
  // Charts and data visualization would be implemented here
  // For a pure HTML/CSS/JS implementation, we would use libraries like Chart.js
  
  // Example of how to create a simple chart with Chart.js
  // This is commented out since we're not including Chart.js in this example
  /*
  if (typeof Chart !== 'undefined') {
    const monthlyContributionsCtx = document.getElementById('monthly-contributions-chart');
    if (monthlyContributionsCtx) {
      new Chart(monthlyContributionsCtx, {
        type: 'line',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
          datasets: [{
            label: 'Contributions',
            data: [5, 8, 12, 10, 15, 18, 20, 22, 25, 28, 30, 32],
            borderColor: getComputedStyle(document.documentElement)
              .getPropertyValue('--developer-purple')
              .trim(),
            tension: 0.3,
            fill: false
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false
        }
      });
    }
  }
  */
});