document.addEventListener("DOMContentLoaded", () => {
  // Set current year in footer
  const currentYearElement = document.getElementById("current-year");
  if (currentYearElement) {
    currentYearElement.textContent = new Date().getFullYear();
  }

  // Typing animation
  const typingElement = document.getElementById("typing-text");
  if (typingElement) {
    const fullText = "Connecting Developers and Entrepreneurs to Co-Create Innovations";
    let i = 0;

    function typeWriter() {
      if (i < fullText.length) {
        typingElement.textContent += fullText.charAt(i);
        i++;
        setTimeout(typeWriter, 100);
      }
    }

    typeWriter();
  }

  // Theme toggle
  const themeToggle = document.getElementById("theme-toggle");
  const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)");

  // Check for saved theme preference or use the system preference
  const savedTheme = localStorage.getItem("theme");

  if (savedTheme === "dark" || (!savedTheme && prefersDarkScheme.matches)) {
    document.body.classList.add("dark");
  } else {
    document.body.classList.remove("dark");
  }

  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      // Toggle dark class on body
      document.body.classList.toggle("dark");

      // Save preference to localStorage
      if (document.body.classList.contains("dark")) {
        localStorage.setItem("theme", "dark");
      } else {
        localStorage.setItem("theme", "light");
      }
    });
  }

  // Tab switching
  const tabTriggers = document.querySelectorAll(".tab-trigger");
  if (tabTriggers.length > 0) {
    tabTriggers.forEach(trigger => {
      trigger.addEventListener("click", () => {
        // Remove active class from all triggers and contents
        document.querySelectorAll(".tab-trigger").forEach(t => t.classList.remove("active"));
        document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
        
        // Add active class to clicked trigger and corresponding content
        trigger.classList.add("active");
        const tabName = trigger.getAttribute("data-tab");
        document.getElementById(`${tabName}-form`).classList.add("active");
      });
    });
  }

  // Form toggling (login/signup)
  const formTogglers = document.querySelectorAll(".toggle-form");
  if (formTogglers.length > 0) {
    formTogglers.forEach(toggler => {
      toggler.addEventListener("click", () => {
        const formToShow = toggler.getAttribute("data-form");
        const role = formToShow.includes("developer") ? "developer" : "entrepreneur";
        
        // Hide all forms for this role
        document.querySelectorAll(`[id^="${role}-"]`).forEach(form => {
          if (form.classList.contains("card")) {
            form.classList.add("hidden");
          }
        });
        
        // Show the target form
        document.getElementById(formToShow).classList.remove("hidden");
      });
    });
  }

  // Handle login/signup forms submission
  const loginForms = document.querySelectorAll("form[id$='-login-form']");
  const signupForms = document.querySelectorAll("form[id$='-signup-form']");
  const otpForms = document.querySelectorAll("form[id$='-otp-form']");

  // Login form submission
  if (loginForms.length > 0) {
    loginForms.forEach(form => {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const role = form.id.includes("developer") ? "developer" : "entrepreneur";
        
        // Show OTP verification form
        document.querySelectorAll(`[id^="${role}-"]`).forEach(el => {
          if (el.classList.contains("card")) {
            el.classList.add("hidden");
          }
        });
        document.getElementById(`${role}-otp`).classList.remove("hidden");
      });
    });
  }

  // Signup form submission
  if (signupForms.length > 0) {
    signupForms.forEach(form => {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const role = form.id.includes("developer") ? "developer" : "entrepreneur";
        
        // Show OTP verification form
        document.querySelectorAll(`[id^="${role}-"]`).forEach(el => {
          if (el.classList.contains("card")) {
            el.classList.add("hidden");
          }
        });
        document.getElementById(`${role}-otp`).classList.remove("hidden");
      });
    });
  }

  // OTP form submission
  if (otpForms.length > 0) {
    otpForms.forEach(form => {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const role = form.id.includes("developer") ? "developer" : "entrepreneur";
        
        // Redirect to dashboard
        window.location.href = `${role}/dashboard.html`;
      });
    });
  }

  // Handle URL parameters for role selection
  const urlParams = new URLSearchParams(window.location.search);
  const role = urlParams.get("role");

  if (role) {
    // If on login page, set the active tab based on role parameter
    const developerTab = document.getElementById("developer-tab");
    const entrepreneurTab = document.getElementById("entrepreneur-tab");

    if (developerTab && entrepreneurTab) {
      if (role === "developer") {
        developerTab.click();
      } else if (role === "entrepreneur") {
        entrepreneurTab.click();
      }
    }
  }
});