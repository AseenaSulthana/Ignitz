from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from app import db

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'developer' or 'entrepreneur'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<User {self.email}>'

class DeveloperProfile(db.Model):
    __tablename__ = 'developer_profiles'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    skills = db.Column(db.Text)
    qualification = db.Column(db.Text)
    bio = db.Column(db.Text)
    location = db.Column(db.String(255))
    portfolio_url = db.Column(db.String(255))
    github_url = db.Column(db.String(255))
    linkedin_url = db.Column(db.String(255))
    ignitz_score = db.Column(db.Integer, default=0)
    
    user = db.relationship('User', backref=db.backref('developer_profile', lazy=True))
    
    def __repr__(self):
        return f'<DeveloperProfile {self.user_id}>'

class EntrepreneurProfile(db.Model):
    __tablename__ = 'entrepreneur_profiles'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    organization = db.Column(db.String(255))
    startup_domain = db.Column(db.String(255))
    bio = db.Column(db.Text)
    location = db.Column(db.String(255))
    website_url = db.Column(db.String(255))
    
    user = db.relationship('User', backref=db.backref('entrepreneur_profile', lazy=True))
    
    def __repr__(self):
        return f'<EntrepreneurProfile {self.user_id}>'

class Project(db.Model):
    __tablename__ = 'projects'
    
    id = db.Column(db.Integer, primary_key=True)
    entrepreneur_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    budget_min = db.Column(db.Numeric(10, 2))
    budget_max = db.Column(db.Numeric(10, 2))
    duration = db.Column(db.String(100))
    status = db.Column(db.String(20), default='active')  # 'active', 'completed', 'cancelled'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    entrepreneur = db.relationship('User', backref=db.backref('projects', lazy=True))
    
    def __repr__(self):
        return f'<Project {self.title}>'

class ProjectSkill(db.Model):
    __tablename__ = 'project_skills'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    skill = db.Column(db.String(100), nullable=False)
    
    project = db.relationship('Project', backref=db.backref('skills', lazy=True))
    
    def __repr__(self):
        return f'<ProjectSkill {self.skill}>'

class ProjectBid(db.Model):
    __tablename__ = 'project_bids'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    developer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    bid_amount = db.Column(db.Numeric(10, 2))
    proposal = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')  # 'pending', 'accepted', 'rejected'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    project = db.relationship('Project', backref=db.backref('bids', lazy=True))
    developer = db.relationship('User', backref=db.backref('bids', lazy=True))
    
    def __repr__(self):
        return f'<ProjectBid {self.id}>'

class SkillEndorsement(db.Model):
    __tablename__ = 'skill_endorsements'
    
    id = db.Column(db.Integer, primary_key=True)
    endorser_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    developer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    skill = db.Column(db.String(100), nullable=False)
    endorsed_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    endorser = db.relationship('User', foreign_keys=[endorser_id], backref=db.backref('endorsements_given', lazy=True))
    developer = db.relationship('User', foreign_keys=[developer_id], backref=db.backref('endorsements_received', lazy=True))
    
    def __repr__(self):
        return f'<SkillEndorsement {self.skill}>'

class Review(db.Model):
    __tablename__ = 'reviews'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    reviewer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    reviewee_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    project = db.relationship('Project', backref=db.backref('reviews', lazy=True))
    reviewer = db.relationship('User', foreign_keys=[reviewer_id], backref=db.backref('reviews_given', lazy=True))
    reviewee = db.relationship('User', foreign_keys=[reviewee_id], backref=db.backref('reviews_received', lazy=True))
    
    def __repr__(self):
        return f'<Review {self.id}>'
