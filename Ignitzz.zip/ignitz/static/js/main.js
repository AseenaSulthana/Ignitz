import { Chart } from "@/components/ui/chart"
document.addEventListener("DOMContentLoaded", () => {
  // Set current year in footer
  const currentYearElement = document.getElementById("current-year")
  if (currentYearElement) {
    currentYearElement.textContent = new Date().getFullYear()
  }

  // Theme toggle
  const themeToggle = document.getElementById("theme-toggle")
  if (themeToggle) {
    // Check for saved theme preference or use system preference
    const savedTheme = localStorage.getItem("theme")
    const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)")

    if (savedTheme === "dark" || (!savedTheme && prefersDarkScheme.matches)) {
      document.body.classList.add("dark")
    } else {
      document.body.classList.remove("dark")
    }

    themeToggle.addEventListener("click", () => {
      // Toggle dark class on body
      document.body.classList.toggle("dark")

      // Save preference to localStorage
      if (document.body.classList.contains("dark")) {
        localStorage.setItem("theme", "dark")
      } else {
        localStorage.setItem("theme", "light")
      }
    })
  }

  // Mobile sidebar toggle
  const sidebarToggle = document.getElementById("sidebar-toggle")
  const sidebar = document.querySelector(".sidebar")
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener("click", () => {
      sidebar.classList.toggle("open")
    })
  }

  // Flash message close button
  const closeButtons = document.querySelectorAll(".flash-message .close-btn")
  closeButtons.forEach((button) => {
    button.addEventListener("click", function () {
      this.parentElement.remove()
    })
  })

  // Auto-hide flash messages after 5 seconds
  setTimeout(() => {
    const flashMessages = document.querySelectorAll(".flash-message")
    flashMessages.forEach((message) => {
      message.style.opacity = "0"
      message.style.transition = "opacity 0.5s ease"
      setTimeout(() => {
        message.remove()
      }, 500)
    })
  }, 5000)

  // Form validation
  const forms = document.querySelectorAll("form")
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      const requiredFields = form.querySelectorAll("[required]")
      let isValid = true

      requiredFields.forEach((field) => {
        if (!field.value.trim()) {
          isValid = false
          field.classList.add("error")

          // Create error message if it doesn't exist
          let errorMessage = field.nextElementSibling
          if (!errorMessage || !errorMessage.classList.contains("error-message")) {
            errorMessage = document.createElement("div")
            errorMessage.classList.add("error-message")
            errorMessage.textContent = "This field is required"
            field.parentNode.insertBefore(errorMessage, field.nextSibling)
          }
        } else {
          field.classList.remove("error")

          // Remove error message if it exists
          const errorMessage = field.nextElementSibling
          if (errorMessage && errorMessage.classList.contains("error-message")) {
            errorMessage.remove()
          }
        }
      })

      if (!isValid) {
        event.preventDefault()
      }
    })
  })

  // API functions
  const API_URL = "/api"

  // Get projects
  window.getProjects = async () => {
    try {
      const response = await fetch(`${API_URL}/projects`)
      const data = await response.json()
      return data
    } catch (error) {
      console.error("Error fetching projects:", error)
      return []
    }
  }

  // Create project
  window.createProject = async (projectData) => {
    try {
      const response = await fetch(`${API_URL}/projects`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(projectData),
      })

      const data = await response.json()

      if (response.ok) {
        return { success: true, data }
      } else {
        return { success: false, message: data.message || "Failed to create project" }
      }
    } catch (error) {
      console.error("Error creating project:", error)
      return { success: false, message: "An error occurred" }
    }
  }

  // Add skill endorsement
  window.addEndorsement = async (endorsementData) => {
    try {
      const response = await fetch(`${API_URL}/endorsements`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(endorsementData),
      })

      const data = await response.json()

      if (response.ok) {
        return { success: true, data }
      } else {
        return { success: false, message: data.message || "Failed to add endorsement" }
      }
    } catch (error) {
      console.error("Error adding endorsement:", error)
      return { success: false, message: "An error occurred" }
    }
  }

  // Charts (if needed)
  if (typeof Chart !== "undefined") {
    // Monthly contributions chart
    const monthlyContributionsCanvas = document.getElementById("monthly-contributions-chart")
    if (monthlyContributionsCanvas) {
      const ctx = monthlyContributionsCanvas.getContext("2d")
      new Chart(ctx, {
        type: "line",
        data: {
          labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
          datasets: [
            {
              label: "Contributions",
              data: [5, 8, 12, 10, 15, 18, 20, 22, 25, 28, 30, 32],
              borderColor: getComputedStyle(document.documentElement).getPropertyValue("--developer-purple").trim(),
              backgroundColor: "transparent",
              tension: 0.4,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
        },
      })
    }

    // Yearly growth chart
    const yearlyGrowthCanvas = document.getElementById("yearly-growth-chart")
    if (yearlyGrowthCanvas) {
      const ctx = yearlyGrowthCanvas.getContext("2d")
      new Chart(ctx, {
        type: "bar",
        data: {
          labels: ["2019", "2020", "2021", "2022", "2023"],
          datasets: [
            {
              label: "Contributions",
              data: [120, 180, 240, 320, 400],
              backgroundColor: getComputedStyle(document.documentElement).getPropertyValue("--developer-purple").trim(),
            },
            {
              label: "Growth %",
              data: [0, 50, 33, 33, 25],
              backgroundColor: "#82ca9d",
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
        },
      })
    }
  }
})
