"use client"

import * as React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Briefcase, User, LogOut, MessageSquare, FileText, Search, ChevronRight, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { FireIcon } from "@/components/fire-icon"

interface SidebarProps {
  role: "developer" | "entrepreneur"
  userName?: string
}

export function Sidebar({ role, userName = "User" }: SidebarProps) {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = React.useState(false)

  const roleColor = role === "developer" ? "bg-developer-purple" : "bg-entrepreneur-blue"
  const roleTextColor = role === "developer" ? "text-developer-purple" : "text-entrepreneur-blue"

  const developerLinks = [
    { href: "/developer/dashboard", label: "Dashboard", icon: Home },
    { href: "/developer/projects", label: "Browse Projects", icon: Search },
    { href: "/developer/bids", label: "My Bids", icon: Briefcase },
    { href: "/developer/profile", label: "Profile", icon: User },
    { href: "/developer/messages", label: "Messages", icon: MessageSquare },
  ]

  const entrepreneurLinks = [
    { href: "/entrepreneur/dashboard", label: "Dashboard", icon: Home },
    { href: "/entrepreneur/projects", label: "Projects", icon: Briefcase },
    { href: "/entrepreneur/bids", label: "Active Bids", icon: FileText },
    { href: "/entrepreneur/profile", label: "Profile", icon: User },
    { href: "/entrepreneur/resources", label: "Resources", icon: FileText },
  ]

  const links = role === "developer" ? developerLinks : entrepreneurLinks

  return (
    <>
      {/* Mobile Sidebar */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild className="md:hidden">
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle Menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0">
          <div className="h-full flex flex-col">
            <div className={`p-4 ${roleColor}`}>
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-white flex items-center justify-center">
                  <FireIcon className="h-5 w-5 text-primary" />
                </div>
                <h2 className="text-xl font-bold text-white">Ignitz</h2>
              </div>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-4">
                <nav className="space-y-2">
                  {links.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setIsOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                        pathname === link.href ? `${roleColor} text-white` : "hover:bg-muted"
                      }`}
                    >
                      <link.icon className="h-5 w-5" />
                      <span>{link.label}</span>
                      {pathname === link.href && <ChevronRight className="h-4 w-4 ml-auto" />}
                    </Link>
                  ))}
                </nav>
              </div>
            </ScrollArea>
            <div className="p-4 border-t">
              <Link href="/" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted transition-colors">
                <LogOut className="h-5 w-5" />
                <span>Logout</span>
              </Link>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex flex-col flex-1 min-h-0 border-r">
          <div className={`flex items-center gap-2 h-16 px-4 ${roleColor}`}>
            <div className="h-8 w-8 rounded-full bg-white flex items-center justify-center">
              <FireIcon className="h-5 w-5 text-primary" />
            </div>
            <h2 className="text-xl font-bold text-white">Ignitz</h2>
          </div>
          <div className="flex-1 flex flex-col overflow-y-auto">
            <nav className="flex-1 px-4 py-4 space-y-2">
              {links.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                    pathname === link.href ? `${roleColor} text-white` : `hover:bg-muted ${roleTextColor}`
                  }`}
                >
                  <link.icon className="h-5 w-5" />
                  <span>{link.label}</span>
                  {pathname === link.href && <ChevronRight className="h-4 w-4 ml-auto" />}
                </Link>
              ))}
            </nav>
          </div>
          <div className="p-4 border-t">
            <Link
              href="/"
              className={`flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted transition-colors ${roleTextColor}`}
            >
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </Link>
          </div>
        </div>
      </div>
    </>
  )
}
