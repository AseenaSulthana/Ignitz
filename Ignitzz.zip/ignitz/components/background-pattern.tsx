import type React from "react"
import { cn } from "@/lib/utils"

type PatternType = "dots" | "grid" | "waves" | "gradient-purple" | "gradient-blue" | "gradient-violet" | "animated"

interface BackgroundPatternProps {
  pattern: PatternType
  className?: string
  children?: React.ReactNode
}

export function BackgroundPattern({ pattern, className, children }: BackgroundPatternProps) {
  const patternClass = {
    dots: "bg-pattern-dots",
    grid: "bg-pattern-grid",
    waves: "bg-pattern-waves",
    "gradient-purple": "bg-gradient-purple",
    "gradient-blue": "bg-gradient-blue",
    "gradient-violet": "bg-gradient-violet",
    animated: "animated-bg",
  }[pattern]

  return <div className={cn(patternClass, className)}>{children}</div>
}
