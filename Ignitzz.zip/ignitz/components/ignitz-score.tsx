import { FireIcon } from "@/components/fire-icon"

interface IgnitzScoreProps {
  score: number
  className?: string
}

export function IgnitzScore({ score, className }: IgnitzScoreProps) {
  return (
    <div className={`ignitz-score-container ${className}`}>
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-sm font-medium">Ignitz Score</h3>
        <span className="text-xs opacity-80">Excellent</span>
      </div>
      <div className="ignitz-score-value">
        {score}
        <FireIcon className="h-6 w-6 text-yellow-300" />
      </div>
      <div className="ignitz-score-progress">
        <div className="ignitz-score-progress-bar" style={{ width: `${score}%` }}></div>
      </div>
    </div>
  )
}
