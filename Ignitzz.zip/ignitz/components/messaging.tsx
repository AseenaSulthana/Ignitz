"use client"

import { useState, useEffect, useRef } from "react"
import { Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { getUserFromLocalStorage } from "@/lib/auth"

interface Message {
  id: number
  sender_id: number
  receiver_id: number
  content: string
  created_at: string
  is_read: boolean
  sender_first_name?: string
  sender_last_name?: string
  receiver_first_name?: string
  receiver_last_name?: string
}

interface Conversation {
  other_user_id: number
  other_user_first_name: string
  other_user_last_name: string
  content: string
  created_at: string
  is_read: boolean
}

export function Messaging() {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null)
  const [user, setUser] = useState<any>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const userData = getUserFromLocalStorage()
    if (userData) {
      setUser(userData)
      fetchConversations()
    }
  }, [])

  useEffect(() => {
    if (selectedUserId) {
      fetchMessages(selectedUserId)
    }
  }, [selectedUserId])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const fetchConversations = async () => {
    try {
      const response = await fetch("/api/messages")
      if (!response.ok) throw new Error("Failed to fetch conversations")
      const data = await response.json()
      setConversations(data)
    } catch (error) {
      console.error("Error fetching conversations:", error)
    }
  }

  const fetchMessages = async (userId: number) => {
    try {
      const response = await fetch(`/api/messages?userId=${userId}`)
      if (!response.ok) throw new Error("Failed to fetch messages")
      const data = await response.json()
      setMessages(data)
    } catch (error) {
      console.error("Error fetching messages:", error)
    }
  }

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedUserId) return

    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          receiverId: selectedUserId,
          content: newMessage,
        }),
      })

      if (!response.ok) throw new Error("Failed to send message")

      // Add the new message to the list
      const data = await response.json()
      const newMsg: Message = {
        id: data.messageId,
        sender_id: user.id,
        receiver_id: selectedUserId,
        content: newMessage,
        created_at: data.createdAt,
        is_read: false,
        sender_first_name: user.firstName,
        sender_last_name: user.lastName,
      }

      setMessages([...messages, newMsg])
      setNewMessage("")

      // Update conversations list
      fetchConversations()
    } catch (error) {
      console.error("Error sending message:", error)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()

    if (date.toDateString() === now.toDateString()) {
      return "Today"
    }

    const yesterday = new Date(now)
    yesterday.setDate(yesterday.getDate() - 1)
    if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday"
    }

    return date.toLocaleDateString()
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[calc(100vh-10rem)]">
      <Card className="md:col-span-1 h-full">
        <CardHeader>
          <CardTitle>Conversations</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[calc(100vh-14rem)]">
            {conversations.length > 0 ? (
              <div className="divide-y">
                {conversations.map((conversation) => (
                  <div
                    key={conversation.other_user_id}
                    className={`flex items-start gap-3 p-4 cursor-pointer hover:bg-muted transition-colors ${
                      selectedUserId === conversation.other_user_id ? "bg-muted" : ""
                    }`}
                    onClick={() => setSelectedUserId(conversation.other_user_id)}
                  >
                    <Avatar>
                      <AvatarFallback>
                        {conversation.other_user_first_name[0]}
                        {conversation.other_user_last_name[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <h3 className="font-medium truncate">
                          {conversation.other_user_first_name} {conversation.other_user_last_name}
                        </h3>
                        <span className="text-xs text-muted-foreground">{formatTime(conversation.created_at)}</span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{conversation.content}</p>
                    </div>
                    {!conversation.is_read && <div className="w-2 h-2 rounded-full bg-primary mt-2"></div>}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center text-muted-foreground">No conversations yet</div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      <Card className="md:col-span-2 h-full flex flex-col">
        {selectedUserId ? (
          <>
            <CardHeader className="border-b py-4">
              <CardTitle className="text-base">
                {conversations.find((c) => c.other_user_id === selectedUserId)?.other_user_first_name}{" "}
                {conversations.find((c) => c.other_user_id === selectedUserId)?.other_user_last_name}
              </CardTitle>
            </CardHeader>
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((message, index) => {
                  const isCurrentUser = message.sender_id === user.id
                  const showDate =
                    index === 0 || formatDate(messages[index - 1].created_at) !== formatDate(message.created_at)

                  return (
                    <div key={message.id} className="space-y-4">
                      {showDate && (
                        <div className="text-center">
                          <span className="text-xs bg-muted px-2 py-1 rounded-full text-muted-foreground">
                            {formatDate(message.created_at)}
                          </span>
                        </div>
                      )}
                      <div className={`flex ${isCurrentUser ? "justify-end" : "justify-start"}`}>
                        <div
                          className={`flex items-start gap-2 max-w-[80%] ${isCurrentUser ? "flex-row-reverse" : ""}`}
                        >
                          {!isCurrentUser && (
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="text-xs">
                                {message.sender_first_name?.[0]}
                                {message.sender_last_name?.[0]}
                              </AvatarFallback>
                            </Avatar>
                          )}
                          <div>
                            <div
                              className={`px-4 py-2 rounded-lg ${
                                isCurrentUser ? "bg-primary text-primary-foreground" : "bg-muted"
                              }`}
                            >
                              <p>{message.content}</p>
                            </div>
                            <div className={`text-xs text-muted-foreground mt-1 ${isCurrentUser ? "text-right" : ""}`}>
                              {formatTime(message.created_at)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Input
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      sendMessage()
                    }
                  }}
                />
                <Button size="icon" onClick={sendMessage}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            Select a conversation to start messaging
          </div>
        )}
      </Card>
    </div>
  )
}
