from flask import Flask, request, jsonify, session
from flask_cors import CORS
import mysql.connector
import os
import json
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
from datetime import datetime, timedelta
from functools import wraps

app = Flask(__name__)
CORS(app, supports_credentials=True)
app.secret_key = os.environ.get('SECRET_KEY', 'ignitz-secret-key')

# Database configuration
db_config = {
    'host': os.environ.get('DB_HOST', 'localhost'),
    'user': os.environ.get('DB_USER', 'root'),
    'password': os.environ.get('DB_PASSWORD', ''),
    'database': os.environ.get('DB_NAME', 'ignitz_db')
}

# Helper function to get database connection
def get_db_connection():
    return mysql.connector.connect(**db_config)

# Token required decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]
        
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        
        try:
            data = jwt.decode(token, app.secret_key, algorithms=["HS256"])
            current_user_id = data['user_id']
        except:
            return jsonify({'message': 'Token is invalid!'}), 401
            
        return f(current_user_id, *args, **kwargs)
    
    return decorated

# Routes
@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    
    # Check if required fields are present
    required_fields = ['email', 'password', 'first_name', 'last_name', 'role']
    for field in required_fields:
        if field not in data:
            return jsonify({'message': f'Missing required field: {field}'}), 400
    
    # Check if user already exists
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE email = %s", (data['email'],))
    user = cursor.fetchone()
    
    if user:
        cursor.close()
        conn.close()
        return jsonify({'message': 'User already exists!'}), 409
    
    # Hash the password
    hashed_password = generate_password_hash(data['password'])
    
    # Insert the new user
    try:
        cursor.execute(
            "INSERT INTO users (email, password, first_name, last_name, role) VALUES (%s, %s, %s, %s, %s)",
            (data['email'], hashed_password, data['first_name'], data['last_name'], data['role'])
        )
        user_id = cursor.lastrowid
        
        # Insert additional data based on role
        if data['role'] == 'developer':
            skills = data.get('skills', '')
            qualification = data.get('qualification', '')
            cursor.execute(
                "INSERT INTO developer_profiles (user_id, skills, qualification) VALUES (%s, %s, %s)",
                (user_id, skills, qualification)
            )
        elif data['role'] == 'entrepreneur':
            organization = data.get('organization', '')
            startup_domain = data.get('startup_domain', '')
            cursor.execute(
                "INSERT INTO entrepreneur_profiles (user_id, organization, startup_domain) VALUES (%s, %s, %s)",
                (user_id, organization, startup_domain)
            )
        
        conn.commit()
        
        # Generate token
        token = jwt.encode({
            'user_id': user_id,
            'exp': datetime.utcnow() + timedelta(days=1)
        }, app.secret_key, algorithm="HS256")
        
        return jsonify({
            'message': 'User registered successfully!',
            'token': token,
            'user_id': user_id,
            'role': data['role']
        }), 201
    
    except Exception as e:
        conn.rollback()
        return jsonify({'message': f'Error: {str(e)}'}), 500
    
    finally:
        cursor.close()
        conn.close()

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({'message': 'Email and password are required!'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT * FROM users WHERE email = %s", (data['email'],))
    user = cursor.fetchone()
    
    if not user or not check_password_hash(user['password'], data['password']):
        cursor.close()
        conn.close()
        return jsonify({'message': 'Invalid credentials!'}), 401
    
    # Generate token
    token = jwt.encode({
        'user_id': user['id'],
        'exp': datetime.utcnow() + timedelta(days=1)
    }, app.secret_key, algorithm="HS256")
    
    cursor.close()
    conn.close()
    
    return jsonify({
        'message': 'Login successful!',
        'token': token,
        'user_id': user['id'],
        'role': user['role'],
        'first_name': user['first_name']
    }), 200

@app.route('/api/user/profile', methods=['GET'])
@token_required
def get_user_profile(current_user_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT id, email, first_name, last_name, role FROM users WHERE id = %s", (current_user_id,))
    user = cursor.fetchone()
    
    if not user:
        cursor.close()
        conn.close()
        return jsonify({'message': 'User not found!'}), 404
    
    # Get role-specific profile data
    if user['role'] == 'developer':
        cursor.execute("SELECT * FROM developer_profiles WHERE user_id = %s", (current_user_id,))
        profile = cursor.fetchone()
        
        # Get skill endorsements
        cursor.execute("""
            SELECT skill, COUNT(*) as endorsements 
            FROM skill_endorsements 
            WHERE developer_id = %s 
            GROUP BY skill
        """, (current_user_id,))
        endorsements = cursor.fetchall()
        
    elif user['role'] == 'entrepreneur':
        cursor.execute("SELECT * FROM entrepreneur_profiles WHERE user_id = %s", (current_user_id,))
        profile = cursor.fetchone()
        
        # Get posted projects
        cursor.execute("SELECT * FROM projects WHERE entrepreneur_id = %s", (current_user_id,))
        projects = cursor.fetchall()
        profile['projects'] = projects
    
    cursor.close()
    conn.close()
    
    # Combine user data with profile data
    result = {**user, 'profile': profile}
    if user['role'] == 'developer':
        result['endorsements'] = endorsements
    
    return jsonify(result), 200

@app.route('/api/projects', methods=['GET'])
@token_required
def get_projects(current_user_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    # Get user role
    cursor.execute("SELECT role FROM users WHERE id = %s", (current_user_id,))
    user = cursor.fetchone()
    
    if user['role'] == 'developer':
        # For developers, get all available projects
        cursor.execute("""
            SELECT p.*, u.first_name, u.last_name 
            FROM projects p
            JOIN users u ON p.entrepreneur_id = u.id
            WHERE p.status = 'active'
        """)
    else:
        # For entrepreneurs, get their own projects
        cursor.execute("""
            SELECT p.*, u.first_name, u.last_name 
            FROM projects p
            JOIN users u ON p.entrepreneur_id = u.id
            WHERE p.entrepreneur_id = %s
        """, (current_user_id,))
    
    projects = cursor.fetchall()
    
    # Get skills for each project
    for project in projects:
        cursor.execute("SELECT skill FROM project_skills WHERE project_id = %s", (project['id'],))
        skills = cursor.fetchall()
        project['skills'] = [skill['skill'] for skill in skills]
    
    cursor.close()
    conn.close()
    
    return jsonify(projects), 200

@app.route('/api/projects', methods=['POST'])
@token_required
def create_project(current_user_id):
    data = request.get_json()
    
    # Check if required fields are present
    required_fields = ['title', 'description', 'budget_min', 'budget_max', 'duration', 'skills']
    for field in required_fields:
        if field not in data:
            return jsonify({'message': f'Missing required field: {field}'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    # Check if user is an entrepreneur
    cursor.execute("SELECT role FROM users WHERE id = %s", (current_user_id,))
    user = cursor.fetchone()
    
    if not user or user['role'] != 'entrepreneur':
        cursor.close()
        conn.close()
        return jsonify({'message': 'Only entrepreneurs can create projects!'}), 403
    
    try:
        # Insert project
        cursor.execute("""
            INSERT INTO projects (
                entrepreneur_id, title, description, budget_min, budget_max, 
                duration, status, created_at
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, NOW())
        """, (
            current_user_id, data['title'], data['description'], 
            data['budget_min'], data['budget_max'], data['duration'], 'active'
        ))
        
        project_id = cursor.lastrowid
        
        # Insert project skills
        for skill in data['skills']:
            cursor.execute("INSERT INTO project_skills (project_id, skill) VALUES (%s, %s)", 
                          (project_id, skill))
        
        conn.commit()
        
        return jsonify({
            'message': 'Project created successfully!',
            'project_id': project_id
        }), 201
    
    except Exception as e:
        conn.rollback()
        return jsonify({'message': f'Error: {str(e)}'}), 500
    
    finally:
        cursor.close()
        conn.close()

@app.route('/api/endorsements', methods=['POST'])
@token_required
def add_endorsement(current_user_id):
    data = request.get_json()
    
    if not data or not data.get('developer_id') or not data.get('skill'):
        return jsonify({'message': 'Developer ID and skill are required!'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Check if already endorsed
        cursor.execute("""
            SELECT * FROM skill_endorsements 
            WHERE endorser_id = %s AND developer_id = %s AND skill = %s
        """, (current_user_id, data['developer_id'], data['skill']))
        
        if cursor.fetchone():
            return jsonify({'message': 'You have already endorsed this skill!'}), 409
        
        # Add endorsement
        cursor.execute("""
            INSERT INTO skill_endorsements (endorser_id, developer_id, skill, endorsed_at)
            VALUES (%s, %s, %s, NOW())
        """, (current_user_id, data['developer_id'], data['skill']))
        
        conn.commit()
        
        return jsonify({'message': 'Skill endorsed successfully!'}), 201
    
    except Exception as e:
        conn.rollback()
        return jsonify({'message': f'Error: {str(e)}'}), 500
    
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    app.run(debug=True)
