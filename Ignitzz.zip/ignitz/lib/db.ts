import { Pool } from "pg"

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
})

export async function executeQuery(text: string, params: any[] = []) {
  try {
    const result = await pool.query(text, params)
    return result.rows
  } catch (error) {
    console.error("Database query error:", error)
    throw error
  }
}
