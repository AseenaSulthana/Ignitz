import { cookies } from "next/headers"
import { jwtVerify } from "jose"

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key")

export async function getUser(request: Request) {
  // For API routes
  const cookieStore = cookies()
  const token = cookieStore.get("auth_token")?.value

  if (!token) {
    return null
  }

  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    return payload
  } catch (error) {
    return null
  }
}

// Client-side function to get user from localStorage
export function getUserFromLocalStorage() {
  if (typeof window === "undefined") {
    return null
  }

  const user = localStorage.getItem("user")
  if (!user) {
    return null
  }

  try {
    return JSON.parse(user)
  } catch (error) {
    return null
  }
}
