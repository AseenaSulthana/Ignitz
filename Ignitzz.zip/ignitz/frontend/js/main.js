document.addEventListener("DOMContentLoaded", () => {
  // Set current year in footer
  document.getElementById("current-year").textContent = new Date().getFullYear()

  // Typing animation
  const typingElement = document.getElementById("typing-text")
  const fullText = "Connecting Developers and Entrepreneurs to Co-Create Innovations"
  let i = 0

  function typeWriter() {
    if (i < fullText.length) {
      typingElement.textContent += fullText.charAt(i)
      i++
      setTimeout(typeWriter, 100)
    }
  }

  typeWriter()

  // Theme toggle
  const themeToggle = document.getElementById("theme-toggle")
  const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)")

  // Check for saved theme preference or use the system preference
  const savedTheme = localStorage.getItem("theme")

  if (savedTheme === "dark" || (!savedTheme && prefersDarkScheme.matches)) {
    document.body.classList.add("dark")
  } else {
    document.body.classList.remove("dark")
  }

  themeToggle.addEventListener("click", () => {
    // Toggle dark class on body
    document.body.classList.toggle("dark")

    // Save preference to localStorage
    if (document.body.classList.contains("dark")) {
      localStorage.setItem("theme", "dark")
    } else {
      localStorage.setItem("theme", "light")
    }
  })

  // Handle login/signup links
  const urlParams = new URLSearchParams(window.location.search)
  const role = urlParams.get("role")

  if (role) {
    // If on login page, set the active tab based on role parameter
    const developerTab = document.getElementById("developer-tab")
    const entrepreneurTab = document.getElementById("entrepreneur-tab")

    if (developerTab && entrepreneurTab) {
      if (role === "developer") {
        developerTab.classList.add("active")
        entrepreneurTab.classList.remove("active")
        document.getElementById("developer-form").style.display = "block"
        document.getElementById("entrepreneur-form").style.display = "none"
      } else if (role === "entrepreneur") {
        entrepreneurTab.classList.add("active")
        developerTab.classList.remove("active")
        document.getElementById("entrepreneur-form").style.display = "block"
        document.getElementById("developer-form").style.display = "none"
      }
    }
  }
})

// API integration functions
const API_URL = "http://localhost:5000/api"

// Register function
async function register(userData) {
  try {
    const response = await fetch(`${API_URL}/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(userData),
    })

    const data = await response.json()

    if (response.ok) {
      // Store token and user info
      localStorage.setItem("token", data.token)
      localStorage.setItem(
        "user",
        JSON.stringify({
          id: data.user_id,
          role: data.role,
          firstName: userData.first_name,
        }),
      )

      // Redirect to appropriate dashboard
      window.location.href = `/${data.role}/dashboard.html`
    } else {
      throw new Error(data.message || "Registration failed")
    }
  } catch (error) {
    console.error("Registration error:", error)
    alert(error.message)
  }
}

// Login function
async function login(email, password) {
  try {
    const response = await fetch(`${API_URL}/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    })

    const data = await response.json()

    if (response.ok) {
      // Store token and user info
      localStorage.setItem("token", data.token)
      localStorage.setItem(
        "user",
        JSON.stringify({
          id: data.user_id,
          role: data.role,
          firstName: data.first_name,
        }),
      )

      // Redirect to appropriate dashboard
      window.location.href = `/${data.role}/dashboard.html`
    } else {
      throw new Error(data.message || "Login failed")
    }
  } catch (error) {
    console.error("Login error:", error)
    alert(error.message)
  }
}

// Get user profile
async function getUserProfile() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      throw new Error("No authentication token found")
    }

    const response = await fetch(`${API_URL}/user/profile`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    const data = await response.json()

    if (response.ok) {
      return data
    } else {
      throw new Error(data.message || "Failed to fetch profile")
    }
  } catch (error) {
    console.error("Profile error:", error)
    throw error
  }
}

// Check if user is logged in
function isLoggedIn() {
  return localStorage.getItem("token") !== null
}

// Logout function
function logout() {
  localStorage.removeItem("token")
  localStorage.removeItem("user")
  window.location.href = "/index.html"
}

const Actions = {
  "Implement Python backend": "Set up the Python Flask backend with MySQL database integration",
  "Add skill endorsement feature": "Implement the skill endorsement functionality for developers",
  "Create project posting system": "Build the project posting and bidding system for entrepreneurs",
  "Enhance dashboard statistics": "Add more detailed graphical statistics to the developer dashboard",
  "Implement ideathon feature": "Create the ideathon hosting and participation functionality",
}
