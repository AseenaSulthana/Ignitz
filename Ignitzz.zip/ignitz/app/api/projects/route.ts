import { NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { getUser } from "@/lib/auth"

// Get projects
export async function GET(request: Request) {
  try {
    const user = await getUser(request)

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    let projects

    if (user.role === "entrepreneur") {
      // Get entrepreneur's own projects
      projects = await executeQuery("SELECT * FROM projects WHERE entrepreneur_id = $1 ORDER BY created_at DESC", [
        user.userId,
      ])
    } else {
      // Get all active projects for developers
      projects = await executeQuery(
        `SELECT p.*, u.first_name, u.last_name, u.email 
         FROM projects p
         JOIN users u ON p.entrepreneur_id = u.id
         WHERE p.status = 'active'
         ORDER BY p.created_at DESC`,
        [],
      )
    }

    return NextResponse.json(projects)
  } catch (error) {
    console.error("Error fetching projects:", error)
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 })
  }
}

// Create a new project
export async function POST(request: Request) {
  try {
    const user = await getUser(request)

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    if (user.role !== "entrepreneur") {
      return NextResponse.json({ error: "Only entrepreneurs can create projects" }, { status: 403 })
    }

    const body = await request.json()
    const {
      title,
      description,
      techStack,
      duration,
      stipend,
      membersNeeded,
      company,
      location,
      companyWebsite,
      contactEmail,
    } = body

    // Validate required fields
    if (!title || !description || !techStack || !duration || !stipend) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Insert project
    const result = await executeQuery(
      `INSERT INTO projects (
        entrepreneur_id, title, description, tech_stack, duration, 
        stipend, members_needed, company, location, company_website, 
        contact_email, status, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW(), NOW()) RETURNING *`,
      [
        user.userId,
        title,
        description,
        techStack,
        duration,
        stipend,
        membersNeeded,
        company,
        location,
        companyWebsite,
        contactEmail,
        "active",
      ],
    )

    return NextResponse.json({
      success: true,
      message: "Project created successfully",
      project: result[0],
    })
  } catch (error) {
    console.error("Error creating project:", error)
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 })
  }
}
