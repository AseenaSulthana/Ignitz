import { NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import bcrypt from "bcryptjs"
import { SignJWT } from "jose"
import { cookies } from "next/headers"

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key")

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email, password, firstName, lastName, role, ...profileData } = body

    // Check if user already exists
    const existingUser = await executeQuery("SELECT * FROM users WHERE email = $1", [email])

    if (existingUser.length > 0) {
      return NextResponse.json({ error: "User with this email already exists" }, { status: 400 })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Insert user
    const result = await executeQuery(
      "INSERT INTO users (email, password, first_name, last_name, role) VALUES ($1, $2, $3, $4, $5) RETURNING id",
      [email, hashedPassword, firstName, lastName, role],
    )

    const userId = result[0].id

    // Insert profile data based on role
    if (role === "developer") {
      const { skills, qualification, bio, location, portfolioUrl, githubUrl, linkedinUrl } = profileData

      await executeQuery(
        "INSERT INTO developer_profiles (user_id, skills, qualification, bio, location, portfolio_url, github_url, linkedin_url) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)",
        [
          userId,
          skills || "",
          qualification || "",
          bio || "",
          location || "",
          portfolioUrl || "",
          githubUrl || "",
          linkedinUrl || "",
        ],
      )
    } else if (role === "entrepreneur") {
      const { organization, startupDomain, bio, location, websiteUrl, contactEmail } = profileData

      await executeQuery(
        "INSERT INTO entrepreneur_profiles (user_id, organization, startup_domain, bio, location, website_url, contact_email) VALUES ($1, $2, $3, $4, $5, $6, $7)",
        [
          userId,
          organization || "",
          startupDomain || "",
          bio || "",
          location || "",
          websiteUrl || "",
          contactEmail || "",
        ],
      )
    }

    // Generate JWT token
    const token = await new SignJWT({
      userId: userId,
      email: email,
      role: role,
      name: `${firstName} ${lastName}`,
    })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("7d")
      .sign(JWT_SECRET)

    // Set cookie
    cookies().set({
      name: "auth_token",
      value: token,
      httpOnly: true,
      path: "/",
      maxAge: 60 * 60 * 24 * 7, // 7 days
      sameSite: "strict",
      secure: process.env.NODE_ENV === "production",
    })

    return NextResponse.json({
      success: true,
      message: "User registered successfully",
      userId,
    })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: "Failed to register user" }, { status: 500 })
  }
}
