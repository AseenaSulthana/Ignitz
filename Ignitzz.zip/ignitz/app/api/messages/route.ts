import { NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { getUser } from "@/lib/auth"

// Get all messages for the current user
export async function GET(request: Request) {
  try {
    const user = await getUser(request)

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const conversationWith = searchParams.get("with")

    let messages

    if (conversationWith) {
      // Get messages between current user and specified user
      messages = await executeQuery(
        `SELECT m.*, 
          u1.first_name as sender_first_name, u1.last_name as sender_last_name,
          u2.first_name as receiver_first_name, u2.last_name as receiver_last_name
        FROM messages m
        JOIN users u1 ON m.sender_id = u1.id
        JOIN users u2 ON m.receiver_id = u2.id
        WHERE (m.sender_id = $1 AND m.receiver_id = $2)
        OR (m.sender_id = $2 AND m.receiver_id = $1)
        ORDER BY m.created_at ASC`,
        [user.userId, conversationWith],
      )

      // Mark messages as read
      await executeQuery(
        "UPDATE messages SET is_read = true WHERE sender_id = $1 AND receiver_id = $2 AND is_read = false",
        [conversationWith, user.userId],
      )
    } else {
      // Get all conversations for the current user
      const conversations = await executeQuery(
        `SELECT 
          CASE 
            WHEN m.sender_id = $1 THEN m.receiver_id 
            ELSE m.sender_id 
          END as conversation_with,
          u.first_name, u.last_name, u.role,
          MAX(m.created_at) as last_message_time,
          COUNT(CASE WHEN m.is_read = false AND m.receiver_id = $1 THEN 1 END) as unread_count
        FROM messages m
        JOIN users u ON (
          CASE 
            WHEN m.sender_id = $1 THEN m.receiver_id 
            ELSE m.sender_id 
          END = u.id
        )
        WHERE m.sender_id = $1 OR m.receiver_id = $1
        GROUP BY conversation_with, u.first_name, u.last_name, u.role
        ORDER BY last_message_time DESC`,
        [user.userId],
      )

      messages = conversations
    }

    return NextResponse.json(messages)
  } catch (error) {
    console.error("Error fetching messages:", error)
    return NextResponse.json({ error: "Failed to fetch messages" }, { status: 500 })
  }
}

// Send a new message
export async function POST(request: Request) {
  try {
    const user = await getUser(request)

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { receiverId, content } = body

    if (!receiverId || !content) {
      return NextResponse.json({ error: "Receiver ID and content are required" }, { status: 400 })
    }

    // Insert the message
    const result = await executeQuery(
      "INSERT INTO messages (sender_id, receiver_id, content, created_at) VALUES ($1, $2, $3, NOW()) RETURNING *",
      [user.userId, receiverId, content],
    )

    return NextResponse.json({
      success: true,
      message: result[0],
    })
  } catch (error) {
    console.error("Error sending message:", error)
    return NextResponse.json({ error: "Failed to send message" }, { status: 500 })
  }
}
