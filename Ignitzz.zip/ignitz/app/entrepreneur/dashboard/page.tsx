"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { BackgroundPattern } from "@/components/background-pattern"
import { getUserFromLocalStorage } from "@/lib/auth"
import { PlusCircle, Users, Briefcase, MessageSquare, Bell } from "lucide-react"

export default function EntrepreneurDashboard() {
  const [user, setUser] = useState<any>(null)
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const userData = getUserFromLocalStorage()
    if (userData) {
      setUser(userData)
    }

    // Fetch projects
    const fetchProjects = async () => {
      try {
        const res = await fetch("/api/projects")
        const data = await res.json()
        setProjects(data)
      } catch (error) {
        console.error("Error fetching projects:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProjects()
  }, [])

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50 relative">
      <BackgroundPattern className="absolute inset-0 z-0 opacity-10" />

      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-64 bg-[#03256C] text-white z-20 shadow-xl">
        <div className="p-6">
          <h1 className="text-2xl font-bold">Ignitz</h1>
          <p className="text-blue-200 text-sm">Entrepreneur Portal</p>
        </div>

        <div className="mt-6">
          <div className="px-6 py-3 bg-blue-800 border-l-4 border-white">
            <Link href="/entrepreneur/dashboard" className="flex items-center">
              <Briefcase className="mr-3 h-5 w-5" />
              Dashboard
            </Link>
          </div>

          <div className="px-6 py-3 hover:bg-blue-800 transition-colors">
            <Link href="/entrepreneur/projects" className="flex items-center">
              <PlusCircle className="mr-3 h-5 w-5" />
              Post Project
            </Link>
          </div>

          <div className="px-6 py-3 hover:bg-blue-800 transition-colors">
            <Link href="/entrepreneur/developers" className="flex items-center">
              <Users className="mr-3 h-5 w-5" />
              Find Developers
            </Link>
          </div>

          <div className="px-6 py-3 hover:bg-blue-800 transition-colors">
            <Link href="/entrepreneur/messages" className="flex items-center">
              <MessageSquare className="mr-3 h-5 w-5" />
              Messages
            </Link>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-blue-800">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-blue-200 flex items-center justify-center text-blue-800 font-bold">
              {user.firstName?.[0]}
              {user.lastName?.[0]}
            </div>
            <div className="ml-3">
              <p className="font-medium">
                {user.firstName} {user.lastName}
              </p>
              <p className="text-sm text-blue-200">{user.email}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="ml-64 p-8 relative z-10">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Welcome, {user.firstName}!</h1>

          <div className="flex items-center">
            <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 relative">
              <Bell className="h-5 w-5 text-gray-600" />
              <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-red-500"></span>
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-[#03256C]">
            <h3 className="text-lg font-medium text-gray-500">Active Projects</h3>
            <p className="text-3xl font-bold mt-2">3</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-[#03256C]">
            <h3 className="text-lg font-medium text-gray-500">Applications</h3>
            <p className="text-3xl font-bold mt-2">12</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-[#03256C]">
            <h3 className="text-lg font-medium text-gray-500">Messages</h3>
            <p className="text-3xl font-bold mt-2">5</p>
          </div>
        </div>

        {/* Projects */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">Your Projects</h2>
            <Link
              href="/entrepreneur/projects/new"
              className="px-4 py-2 bg-[#03256C] text-white rounded-md hover:bg-blue-800 transition-colors flex items-center"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Post New Project
            </Link>
          </div>

          {loading ? (
            <p>Loading projects...</p>
          ) : projects.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 mb-4">You haven't posted any projects yet.</p>
              <Link
                href="/entrepreneur/projects/new"
                className="px-4 py-2 bg-[#03256C] text-white rounded-md hover:bg-blue-800 transition-colors inline-flex items-center"
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                Post Your First Project
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Project</th>
                    <th className="text-left py-3 px-4">Tech Stack</th>
                    <th className="text-left py-3 px-4">Applications</th>
                    <th className="text-left py-3 px-4">Status</th>
                    <th className="text-left py-3 px-4">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {/* Sample project data - replace with actual data */}
                  <tr className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-medium">Mobile App Development</p>
                        <p className="text-sm text-gray-500">Posted 3 days ago</p>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1">
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">React Native</span>
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Firebase</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">5</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">Active</span>
                    </td>
                    <td className="py-3 px-4">
                      <button className="text-blue-600 hover:underline">View</button>
                    </td>
                  </tr>
                  <tr className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-medium">E-commerce Website</p>
                        <p className="text-sm text-gray-500">Posted 1 week ago</p>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1">
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Next.js</span>
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Node.js</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">3</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">Active</span>
                    </td>
                    <td className="py-3 px-4">
                      <button className="text-blue-600 hover:underline">View</button>
                    </td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-medium">AI Chatbot</p>
                        <p className="text-sm text-gray-500">Posted 2 weeks ago</p>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1">
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Python</span>
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">TensorFlow</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">4</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">Active</span>
                    </td>
                    <td className="py-3 px-4">
                      <button className="text-blue-600 hover:underline">View</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Top Developers */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-bold mb-6">Top Developers</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-bold">
                  JS
                </div>
                <div className="ml-3">
                  <p className="font-medium">John Smith</p>
                  <p className="text-sm text-gray-500">Full Stack Developer</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mb-3">
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">React</span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Node.js</span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">MongoDB</span>
              </div>
              <button className="w-full py-2 text-[#03256C] border border-[#03256C] rounded hover:bg-[#03256C] hover:text-white transition-colors">
                View Profile
              </button>
            </div>

            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-bold">
                  AP
                </div>
                <div className="ml-3">
                  <p className="font-medium">Aisha Patel</p>
                  <p className="text-sm text-gray-500">Mobile Developer</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mb-3">
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Flutter</span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Firebase</span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Swift</span>
              </div>
              <button className="w-full py-2 text-[#03256C] border border-[#03256C] rounded hover:bg-[#03256C] hover:text-white transition-colors">
                View Profile
              </button>
            </div>

            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-bold">
                  RK
                </div>
                <div className="ml-3">
                  <p className="font-medium">Raj Kumar</p>
                  <p className="text-sm text-gray-500">Backend Developer</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mb-3">
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Python</span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">Django</span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">PostgreSQL</span>
              </div>
              <button className="w-full py-2 text-[#03256C] border border-[#03256C] rounded hover:bg-[#03256C] hover:text-white transition-colors">
                View Profile
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
