"use client"

import Link from "next/link"
import { Sidebar } from "@/components/sidebar"
import { ModeToggle } from "@/components/mode-toggle"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { BackgroundPattern } from "@/components/background-pattern"
import { Bell, ArrowRight } from "lucide-react"
import { FireIcon } from "@/components/fire-icon"

export default function MissionPage() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar role="developer" />

      <div className="md:pl-64">
        <BackgroundPattern pattern="gradient-violet" className="min-h-screen">
          <header className="h-16 border-b flex items-center justify-between px-4 bg-background/80 backdrop-blur-sm">
            <h1 className="text-xl font-bold">Our Mission</h1>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <ModeToggle />
              <Avatar>
                <AvatarImage src="/placeholder.svg" alt="@user" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
            </div>
          </header>

          <main className="p-4 md:p-6">
            <div className="max-w-4xl mx-auto">
              <section className="mb-12 text-center">
                <div className="flex justify-center mb-6">
                  <div className="h-16 w-16 rounded-full bg-primary flex items-center justify-center text-white">
                    <FireIcon className="h-10 w-10" />
                  </div>
                </div>
                <h2 className="text-4xl font-bold mb-4">Igniting Innovation Through Collaboration</h2>
                <p className="text-xl text-muted-foreground">
                  Connecting talented developers with visionary entrepreneurs to co-create the next generation of
                  technological innovations.
                </p>
              </section>

              <section className="mb-12">
                <Card>
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
                    <p className="mb-6">
                      At Ignitz, we envision a world where great ideas never go unrealized due to lack of technical
                      expertise, and where talented developers can find meaningful projects that challenge their skills
                      and advance their careers.
                    </p>
                    <p>
                      We're building a platform that breaks down the barriers between those who have innovative ideas
                      and those who have the technical skills to bring them to life. By fostering collaboration between
                      entrepreneurs and developers, we're creating an ecosystem where innovation thrives and
                      groundbreaking solutions emerge.
                    </p>
                  </CardContent>
                </Card>
              </section>

              <section className="mb-12">
                <h3 className="text-2xl font-bold mb-6">What We Believe</h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <Card>
                    <CardContent className="p-6">
                      <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          className="h-6 w-6 text-primary"
                        >
                          <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5" />
                          <path d="M9 18h6" />
                          <path d="M10 22h4" />
                        </svg>
                      </div>
                      <h4 className="text-lg font-bold mb-2">Innovation is Collaborative</h4>
                      <p className="text-muted-foreground">
                        The best innovations come from diverse teams working together, combining different perspectives
                        and skill sets.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          className="h-6 w-6 text-primary"
                        >
                          <path d="M12 2v4" />
                          <path d="M12 18v4" />
                          <path d="m4.93 4.93 2.83 2.83" />
                          <path d="m16.24 16.24 2.83 2.83" />
                          <path d="M2 12h4" />
                          <path d="M18 12h4" />
                          <path d="m4.93 19.07 2.83-2.83" />
                          <path d="m16.24 7.76 2.83-2.83" />
                        </svg>
                      </div>
                      <h4 className="text-lg font-bold mb-2">Skills Should Be Recognized</h4>
                      <p className="text-muted-foreground">
                        Developers deserve recognition for their expertise and contributions through endorsements and
                        fair compensation.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          className="h-6 w-6 text-primary"
                        >
                          <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                          <circle cx="9" cy="7" r="4" />
                          <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                          <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                        </svg>
                      </div>
                      <h4 className="text-lg font-bold mb-2">Connections Matter</h4>
                      <p className="text-muted-foreground">
                        Building meaningful connections between entrepreneurs and developers creates opportunities for
                        both parties to grow and succeed.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </section>

              <section className="mb-12">
                <Card>
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold mb-4">Our Approach</h3>
                    <ul className="space-y-4">
                      <li className="flex gap-4">
                        <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white shrink-0">
                          1
                        </div>
                        <div>
                          <h4 className="font-bold">Skill-Based Matching</h4>
                          <p className="text-muted-foreground">
                            We use advanced algorithms to match developers with projects that align with their skills,
                            interests, and career goals.
                          </p>
                        </div>
                      </li>
                      <li className="flex gap-4">
                        <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white shrink-0">
                          2
                        </div>
                        <div>
                          <h4 className="font-bold">Transparent Collaboration</h4>
                          <p className="text-muted-foreground">
                            Our platform provides tools for clear communication, project management, and fair
                            compensation agreements.
                          </p>
                        </div>
                      </li>
                      <li className="flex gap-4">
                        <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white shrink-0">
                          3
                        </div>
                        <div>
                          <h4 className="font-bold">Community Building</h4>
                          <p className="text-muted-foreground">
                            We foster a supportive community through ideathons, networking events, and knowledge sharing
                            opportunities.
                          </p>
                        </div>
                      </li>
                      <li className="flex gap-4">
                        <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white shrink-0">
                          4
                        </div>
                        <div>
                          <h4 className="font-bold">Continuous Growth</h4>
                          <p className="text-muted-foreground">
                            Our Ignitz Score system and skill endorsements help developers showcase their expertise and
                            track their professional growth.
                          </p>
                        </div>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </section>

              <section className="text-center">
                <h3 className="text-2xl font-bold mb-4">Join the Ignitz Community</h3>
                <p className="text-muted-foreground mb-6">
                  Whether you're a developer looking for exciting projects or an entrepreneur with a vision, Ignitz is
                  the platform where innovation happens.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/login?role=developer">
                    <Button size="lg" className="w-full sm:w-auto bg-developer-purple hover:bg-developer-purple/90">
                      Join as Developer
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/login?role=entrepreneur">
                    <Button size="lg" className="w-full sm:w-auto bg-entrepreneur-blue hover:bg-entrepreneur-blue/90">
                      Join as Entrepreneur
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </section>
            </div>
          </main>
        </BackgroundPattern>
      </div>
    </div>
  )
}
