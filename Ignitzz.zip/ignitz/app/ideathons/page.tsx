"use client"

import { Sidebar } from "@/components/sidebar"
import { ModeToggle } from "@/components/mode-toggle"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BackgroundPattern } from "@/components/background-pattern"
import { Bell, Calendar, Users, MapPin, Plus } from "lucide-react"

// Sample data for ideathons
const ideathons = [
  {
    id: 1,
    title: "Fintech Innovation Challenge",
    description: "Develop innovative solutions for financial technology challenges facing modern banking systems.",
    date: "May 20, 2023",
    location: "Virtual",
    organizer: "FinEdge",
    participants: 24,
    categories: ["Fintech", "Innovation", "Banking"],
    prizes: "$10,000 in cash prizes",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    id: 2,
    title: "Healthcare AI Hackathon",
    description: "Create AI-powered solutions to improve patient care and medical diagnostics.",
    date: "June 15, 2023",
    location: "San Francisco, CA",
    organizer: "MediTech Inc.",
    participants: 32,
    categories: ["Healthcare", "AI", "Machine Learning"],
    prizes: "$15,000 in cash prizes + mentorship",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    id: 3,
    title: "Sustainable Tech Challenge",
    description: "Build technology solutions that address environmental sustainability challenges.",
    date: "July 8, 2023",
    location: "Virtual",
    organizer: "EcoTech Alliance",
    participants: 18,
    categories: ["Sustainability", "CleanTech", "IoT"],
    prizes: "$8,000 in cash prizes + incubation opportunity",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    id: 4,
    title: "EdTech Innovation Sprint",
    description: "Reimagine education with technology solutions for remote and hybrid learning environments.",
    date: "August 12, 2023",
    location: "New York, NY",
    organizer: "EduFuture",
    participants: 28,
    categories: ["Education", "EdTech", "Remote Learning"],
    prizes: "$12,000 in cash prizes + product development support",
    image: "/placeholder.svg?height=200&width=400",
  },
]

export default function IdeathonsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar role="developer" />

      <div className="md:pl-64">
        <BackgroundPattern pattern="waves" className="min-h-screen">
          <header className="h-16 border-b flex items-center justify-between px-4 bg-background/80 backdrop-blur-sm">
            <h1 className="text-xl font-bold">Ideathons</h1>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <ModeToggle />
              <Avatar>
                <AvatarImage src="/placeholder.svg" alt="@user" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
            </div>
          </header>

          <main className="p-4 md:p-6">
            <div className="grid gap-6">
              <section>
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
                  <div>
                    <h2 className="text-3xl font-bold">Upcoming Ideathons</h2>
                    <p className="text-muted-foreground">
                      Participate in ideathons to showcase your innovation and connect with like-minded individuals
                    </p>
                  </div>
                  <Button className="mt-4 md:mt-0">
                    <Plus className="h-4 w-4 mr-2" />
                    Host an Ideathon
                  </Button>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  {ideathons.map((ideathon) => (
                    <Card key={ideathon.id} className="overflow-hidden">
                      <div className="h-48 overflow-hidden">
                        <img
                          src={ideathon.image || "/placeholder.svg"}
                          alt={ideathon.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <CardHeader>
                        <CardTitle>{ideathon.title}</CardTitle>
                        <CardDescription>Organized by {ideathon.organizer}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="mb-4">{ideathon.description}</p>
                        <div className="flex flex-wrap gap-2 mb-4">
                          {ideathon.categories.map((category) => (
                            <Badge key={category} variant="secondary">
                              {category}
                            </Badge>
                          ))}
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{ideathon.date}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{ideathon.location}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{ideathon.participants} participants</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              className="h-4 w-4 text-muted-foreground"
                            >
                              <path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z" />
                            </svg>
                            <span className="text-sm font-medium">{ideathon.prizes}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full">Register Now</Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </section>

              <section className="mt-8">
                <h2 className="text-2xl font-bold mb-6">Past Ideathons</h2>
                <div className="grid md:grid-cols-3 gap-4">
                  {[1, 2, 3].map((i) => (
                    <Card key={i}>
                      <CardHeader>
                        <CardTitle>Web3 Innovation Challenge {i}</CardTitle>
                        <CardDescription>March {i * 5}, 2023</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-4">
                          Explored innovative solutions using blockchain and decentralized technologies.
                        </p>
                        <div className="flex gap-2">
                          <Badge variant="outline">Blockchain</Badge>
                          <Badge variant="outline">Web3</Badge>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button variant="outline" className="w-full">
                          View Results
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </section>
            </div>
          </main>
        </BackgroundPattern>
      </div>
    </div>
  )
}
