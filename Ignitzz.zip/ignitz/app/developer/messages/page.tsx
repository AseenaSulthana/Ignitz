"use client"

import { Bell } from "lucide-react"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { BackgroundPattern } from "@/components/background-pattern"
import { Messaging } from "@/components/messaging"
import { getUserFromLocalStorage } from "@/lib/auth"
import { useEffect, useState } from "react"

export default function MessagesPage() {
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const userData = getUserFromLocalStorage()
    if (userData) {
      setUser(userData)
    }
  }, [])

  return (
    <div className="developer-theme min-h-screen bg-background">
      <Sidebar role="developer" userName={user?.firstName || "Developer"} />

      <div className="md:pl-64">
        <BackgroundPattern pattern="gradient-purple" className="min-h-screen">
          <header className="h-16 border-b flex items-center justify-between px-4 bg-background/80 backdrop-blur-sm">
            <h1 className="text-xl font-bold">Messages</h1>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <ModeToggle />
              <Avatar>
                <AvatarImage src="/placeholder.svg" alt="@developer" />
                <AvatarFallback>{user?.firstName?.[0] || "D"}</AvatarFallback>
              </Avatar>
            </div>
          </header>

          <main className="p-4 md:p-6">
            <Messaging />
          </main>
        </BackgroundPattern>
      </div>
    </div>
  )
}
