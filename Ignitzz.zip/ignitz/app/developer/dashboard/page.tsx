"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { BackgroundPattern } from "@/components/background-pattern"
import { getUserFromLocalStorage } from "@/lib/auth"
import { Briefcase, User, MessageSquare, Bell, Code, Star } from "lucide-react"

export default function DeveloperDashboard() {
  const [user, setUser] = useState<any>(null)
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const userData = getUserFromLocalStorage()
    if (userData) {
      setUser(userData)
    }

    // Fetch projects
    const fetchProjects = async () => {
      try {
        const res = await fetch("/api/projects")
        const data = await res.json()
        setProjects(data)
      } catch (error) {
        console.error("Error fetching projects:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProjects()
  }, [])

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50 relative">
      <BackgroundPattern className="absolute inset-0 z-0 opacity-10" />

      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-64 bg-gradient-to-b from-purple-700 to-indigo-900 text-white z-20 shadow-xl">
        <div className="p-6">
          <h1 className="text-2xl font-bold">Ignitz</h1>
          <p className="text-purple-200 text-sm">Developer Portal</p>
        </div>

        <div className="mt-6">
          <div className="px-6 py-3 bg-indigo-800 border-l-4 border-white">
            <Link href="/developer/dashboard" className="flex items-center">
              <Briefcase className="mr-3 h-5 w-5" />
              Dashboard
            </Link>
          </div>

          <div className="px-6 py-3 hover:bg-indigo-800 transition-colors">
            <Link href="/developer/projects" className="flex items-center">
              <Code className="mr-3 h-5 w-5" />
              Browse Projects
            </Link>
          </div>

          <div className="px-6 py-3 hover:bg-indigo-800 transition-colors">
            <Link href="/developer/profile" className="flex items-center">
              <User className="mr-3 h-5 w-5" />
              My Profile
            </Link>
          </div>

          <div className="px-6 py-3 hover:bg-indigo-800 transition-colors">
            <Link href="/developer/messages" className="flex items-center">
              <MessageSquare className="mr-3 h-5 w-5" />
              Messages
            </Link>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-indigo-800">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-purple-200 flex items-center justify-center text-purple-800 font-bold">
              {user.firstName?.[0]}
              {user.lastName?.[0]}
            </div>
            <div className="ml-3">
              <p className="font-medium">
                {user.firstName} {user.lastName}
              </p>
              <p className="text-sm text-purple-200">{user.email}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="ml-64 p-8 relative z-10">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Welcome, {user.firstName}!</h1>

          <div className="flex items-center">
            <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 relative">
              <Bell className="h-5 w-5 text-gray-600" />
              <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-red-500"></span>
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-purple-600">
            <h3 className="text-lg font-medium text-gray-500">Applied Projects</h3>
            <p className="text-3xl font-bold mt-2">2</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-purple-600">
            <h3 className="text-lg font-medium text-gray-500">Skill Endorsements</h3>
            <p className="text-3xl font-bold mt-2">15</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6 border-t-4 border-purple-600">
            <h3 className="text-lg font-medium text-gray-500">Messages</h3>
            <p className="text-3xl font-bold mt-2">3</p>
          </div>
        </div>

        {/* Recommended Projects */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">Recommended Projects</h2>
            <Link href="/developer/projects" className="text-purple-600 hover:underline flex items-center">
              View All
            </Link>
          </div>

          {loading ? (
            <p>Loading projects...</p>
          ) : (
            <div className="space-y-4">
              {/* Sample project data - replace with actual data */}
              <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between">
                  <div>
                    <h3 className="font-medium text-lg">Mobile App Development</h3>
                    <p className="text-gray-500 text-sm">TechStartup Inc.</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">₹30,000 - ₹50,000</p>
                    <p className="text-gray-500 text-sm">3 months</p>
                  </div>
                </div>
                <p className="my-3 text-gray-600">
                  Looking for a skilled mobile developer to build a food delivery app with React Native and Firebase
                  integration.
                </p>
                <div className="flex flex-wrap gap-1 mb-3">
                  <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">React Native</span>
                  <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">Firebase</span>
                  <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">Mobile</span>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-500">Posted 3 days ago</p>
                  <button className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors">
                    Apply Now
                  </button>
                </div>
              </div>

              <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between">
                  <div>
                    <h3 className="font-medium text-lg">E-commerce Website</h3>
                    <p className="text-gray-500 text-sm">ShopEasy Solutions</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">₹40,000 - ₹60,000</p>
                    <p className="text-gray-500 text-sm">2 months</p>
                  </div>
                </div>
                <p className="my-3 text-gray-600">
                  Need a full-stack developer to create an e-commerce platform with Next.js, Node.js, and MongoDB.
                </p>
                <div className="flex flex-wrap gap-1 mb-3">
                  <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">Next.js</span>
                  <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">Node.js</span>
                  <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">MongoDB</span>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-500">Posted 1 week ago</p>
                  <button className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors">
                    Apply Now
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Skills */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-bold mb-6">Your Skills</h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className="font-medium">React.js</span>
                <div className="ml-3 flex">
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-gray-300" />
                </div>
              </div>
              <span className="text-sm text-gray-500">8 endorsements</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className="font-medium">Node.js</span>
                <div className="ml-3 flex">
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-gray-300" />
                  <Star className="h-4 w-4 text-gray-300" />
                </div>
              </div>
              <span className="text-sm text-gray-500">5 endorsements</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className="font-medium">MongoDB</span>
                <div className="ml-3 flex">
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <Star className="h-4 w-4 text-gray-300" />
                  <Star className="h-4 w-4 text-gray-300" />
                </div>
              </div>
              <span className="text-sm text-gray-500">4 endorsements</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
