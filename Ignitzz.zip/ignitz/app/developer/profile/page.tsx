"use client"

import { useState } from "react"
import { Bell, Edit, GitlabIcon as GitHub, Globe, Mail, MapPin, Star } from "lucide-react"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ModeToggle } from "@/components/mode-toggle"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export default function DeveloperProfile() {
  const [isEditing, setIsEditing] = useState(false)

  return (
    <div className="developer-theme min-h-screen bg-background">
      <Sidebar role="developer" />

      <div className="md:pl-64">
        <header className="h-16 border-b flex items-center justify-between px-4">
          <h1 className="text-xl font-bold">My Profile</h1>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <ModeToggle />
            <Avatar>
              <AvatarImage src="/placeholder.svg" alt="@developer" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
          </div>
        </header>

        <main className="p-4 md:p-6">
          <div className="grid gap-6">
            <section>
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="flex flex-col items-center">
                      <Avatar className="h-24 w-24">
                        <AvatarImage src="/placeholder.svg" alt="@developer" />
                        <AvatarFallback className="text-2xl">JD</AvatarFallback>
                      </Avatar>
                      <div className="mt-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${i < 4 ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`}
                            />
                          ))}
                          <span className="text-sm ml-1">4.8</span>
                        </div>
                        <div className="mt-2">
                          <Badge variant="outline">Ignitz Score: 87</Badge>
                        </div>
                      </div>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h2 className="text-2xl font-bold">John Doe</h2>
                          <p className="text-muted-foreground">Full Stack Developer</p>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => setIsEditing(!isEditing)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Profile
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <span>john.doe@example.com</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>San Francisco, CA</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Globe className="h-4 w-4 text-muted-foreground" />
                          <a href="#" className="text-primary hover:underline">
                            portfolio-website.com
                          </a>
                        </div>
                        <div className="flex items-center gap-2">
                          <GitHub className="h-4 w-4 text-muted-foreground" />
                          <a href="#" className="text-primary hover:underline">
                            github.com/johndoe
                          </a>
                        </div>
                      </div>

                      <div className="mt-4">
                        <h3 className="font-medium mb-2">About</h3>
                        <p className="text-muted-foreground">
                          Full Stack Developer with 5+ years of experience building web and mobile applications.
                          Passionate about creating user-friendly interfaces and scalable backend systems. Specialized
                          in React, Node.js, and cloud technologies.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </section>

            {isEditing ? (
              <section>
                <Card>
                  <CardHeader>
                    <CardTitle>Edit Profile</CardTitle>
                    <CardDescription>Update your personal information and skills</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form className="space-y-6">
                      <div className="space-y-4">
                        <h3 className="font-medium">Personal Information</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="firstName">First Name</Label>
                            <Input id="firstName" defaultValue="John" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="lastName">Last Name</Label>
                            <Input id="lastName" defaultValue="Doe" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="email">Email</Label>
                            <Input id="email" type="email" defaultValue="john.doe@example.com" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="location">Location</Label>
                            <Input id="location" defaultValue="San Francisco, CA" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="title">Professional Title</Label>
                            <Input id="title" defaultValue="Full Stack Developer" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="phone">Phone Number</Label>
                            <Input id="phone" type="tel" defaultValue="+1234567890" />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="about">About</Label>
                          <Textarea
                            id="about"
                            rows={4}
                            defaultValue="Full Stack Developer with 5+ years of experience building web and mobile applications. Passionate about creating user-friendly interfaces and scalable backend systems. Specialized in React, Node.js, and cloud technologies."
                          />
                        </div>

                        <h3 className="font-medium mt-6">Skills</h3>
                        <div className="space-y-2">
                          <Label htmlFor="skills">Skills (comma separated)</Label>
                          <Input
                            id="skills"
                            defaultValue="React, Node.js, JavaScript, TypeScript, MongoDB, AWS, UI/UX, Python"
                          />
                        </div>

                        <h3 className="font-medium mt-6">External Links</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="portfolio">Portfolio Website</Label>
                            <Input id="portfolio" defaultValue="https://portfolio-website.com" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="github">GitHub</Label>
                            <Input id="github" defaultValue="https://github.com/johndoe" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="linkedin">LinkedIn</Label>
                            <Input id="linkedin" defaultValue="https://linkedin.com/in/johndoe" />
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-end gap-4">
                        <Button variant="outline" type="button" onClick={() => setIsEditing(false)}>
                          Cancel
                        </Button>
                        <Button type="button" onClick={() => setIsEditing(false)}>
                          Save Changes
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              </section>
            ) : (
              <>
                <section>
                  <Tabs defaultValue="skills">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="skills">Skills & Endorsements</TabsTrigger>
                      <TabsTrigger value="projects">Projects</TabsTrigger>
                      <TabsTrigger value="achievements">Achievements</TabsTrigger>
                    </TabsList>

                    <TabsContent value="skills" className="mt-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Skills & Endorsements</CardTitle>
                          <CardDescription>Skills endorsed by collaborators</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="grid gap-6">
                            {[
                              { skill: "React", endorsements: 24, level: 85 },
                              { skill: "Node.js", endorsements: 18, level: 75 },
                              { skill: "JavaScript", endorsements: 22, level: 90 },
                              { skill: "TypeScript", endorsements: 15, level: 70 },
                              { skill: "UI/UX Design", endorsements: 12, level: 65 },
                              { skill: "MongoDB", endorsements: 14, level: 80 },
                              { skill: "AWS", endorsements: 10, level: 60 },
                              { skill: "Python", endorsements: 8, level: 50 },
                            ].map((skill, index) => (
                              <div key={index} className="space-y-2">
                                <div className="flex items-center justify-between">
                                  <div className="font-medium">{skill.skill}</div>
                                  <div className="text-sm text-muted-foreground">{skill.endorsements} endorsements</div>
                                </div>
                                <div className="flex items-center gap-4">
                                  <Progress value={skill.level} className="h-2 flex-1" />
                                  <div className="text-sm font-medium w-8 text-right">{skill.level}%</div>
                                </div>
                                <div className="flex -space-x-2">
                                  {Array.from({ length: Math.min(5, Math.ceil(skill.endorsements / 5)) }).map(
                                    (_, i) => (
                                      <Avatar key={i} className="h-6 w-6 border-2 border-background">
                                        <AvatarFallback className="text-xs">
                                          {String.fromCharCode(65 + i)}
                                        </AvatarFallback>
                                      </Avatar>
                                    ),
                                  )}
                                  {skill.endorsements > 5 && (
                                    <div className="flex items-center justify-center h-6 w-6 rounded-full bg-muted text-xs">
                                      +{skill.endorsements - 5}
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>

                    <TabsContent value="projects" className="mt-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Projects</CardTitle>
                          <CardDescription>Projects you've worked on</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-6">
                            {[
                              {
                                title: "E-commerce Platform",
                                client: "RetailX",
                                role: "Full Stack Developer",
                                duration: "3 months",
                                description:
                                  "Developed a complete e-commerce solution with product management, cart functionality, and payment processing.",
                                technologies: ["React", "Node.js", "MongoDB", "Stripe"],
                              },
                              {
                                title: "Healthcare Management System",
                                client: "MediTech Inc.",
                                role: "Frontend Developer",
                                duration: "6 months",
                                description:
                                  "Built a patient management dashboard with appointment scheduling and medical record tracking.",
                                technologies: ["React", "TypeScript", "Material UI", "Firebase"],
                              },
                              {
                                title: "Financial Analytics Dashboard",
                                client: "FinEdge",
                                role: "UI Developer",
                                duration: "4 months",
                                description:
                                  "Created interactive data visualizations for financial metrics and investment performance tracking.",
                                technologies: ["JavaScript", "D3.js", "Chart.js", "CSS"],
                              },
                            ].map((project, index) => (
                              <div key={index} className="pb-6 border-b last:border-0 last:pb-0">
                                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                                  <div>
                                    <h3 className="text-lg font-bold">{project.title}</h3>
                                    <p className="text-sm text-muted-foreground">Client: {project.client}</p>
                                    <div className="flex items-center gap-2 mt-1">
                                      <Badge>{project.role}</Badge>
                                      <div className="text-sm text-muted-foreground">Duration: {project.duration}</div>
                                    </div>
                                    <p className="mt-2">{project.description}</p>
                                    <div className="flex flex-wrap gap-1 mt-2">
                                      {project.technologies.map((tech, i) => (
                                        <Badge key={i} variant="outline">
                                          {tech}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>

                    <TabsContent value="achievements" className="mt-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Achievements & Certifications</CardTitle>
                          <CardDescription>Your professional achievements and certifications</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-6">
                            <div>
                              <h3 className="font-medium mb-4">Badges</h3>
                              <div className="flex flex-wrap gap-4">
                                {[
                                  {
                                    name: "Top Contributor",
                                    description: "Awarded to developers with exceptional contributions",
                                  },
                                  { name: "Ideathon Winner", description: "First place in the AI Innovation Ideathon" },
                                  { name: "5-Star Developer", description: "Maintained a 5-star rating for 6 months" },
                                  {
                                    name: "Quick Responder",
                                    description: "Consistently responds to project inquiries within 24 hours",
                                  },
                                ].map((badge, index) => (
                                  <div
                                    key={index}
                                    className="flex flex-col items-center text-center p-4 border rounded-lg w-32"
                                  >
                                    <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center mb-2">
                                      <Star className="h-6 w-6 text-primary" />
                                    </div>
                                    <div className="font-medium text-sm">{badge.name}</div>
                                    <div className="text-xs text-muted-foreground mt-1">{badge.description}</div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div>
                              <h3 className="font-medium mb-4">Certifications</h3>
                              <div className="space-y-4">
                                {[
                                  { name: "AWS Certified Developer", issuer: "Amazon Web Services", date: "2022" },
                                  { name: "React Advanced Concepts", issuer: "Frontend Masters", date: "2021" },
                                  {
                                    name: "MongoDB Database Administrator",
                                    issuer: "MongoDB University",
                                    date: "2020",
                                  },
                                ].map((cert, index) => (
                                  <div
                                    key={index}
                                    className="flex items-start justify-between pb-4 border-b last:border-0 last:pb-0"
                                  >
                                    <div>
                                      <h4 className="font-medium">{cert.name}</h4>
                                      <p className="text-sm text-muted-foreground">Issued by {cert.issuer}</p>
                                    </div>
                                    <div className="text-sm text-muted-foreground">{cert.date}</div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </section>
              </>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}
