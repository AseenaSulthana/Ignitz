"use client"

import { useState } from "react"
import { Bell, Filter, Search } from "lucide-react"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ModeToggle } from "@/components/mode-toggle"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { BackgroundPattern } from "@/components/background-pattern"

export default function BrowseProjects() {
  const [searchQuery, setSearchQuery] = useState("")

  const projects = [
    {
      id: 1,
      title: "E-commerce Website Redesign",
      description:
        "Looking for a skilled frontend developer to redesign our e-commerce platform with modern UI/UX principles and responsive design.",
      client: {
        name: "RetailX",
        rating: 4.8,
        projects: 12,
      },
      skills: ["React", "UI/UX", "Responsive Design", "Tailwind CSS"],
      duration: "3 months",
      budget: "$5,000 - $8,000",
      applicants: 8,
      postedDate: "2 days ago",
    },
    {
      id: 2,
      title: "Mobile App Development",
      description:
        "Need a team to develop a cross-platform mobile application for our healthcare service with patient management and appointment scheduling.",
      client: {
        name: "MediTech Inc.",
        rating: 4.9,
        projects: 8,
      },
      skills: ["React Native", "Firebase", "API Integration", "Mobile UI"],
      duration: "6 months",
      budget: "$15,000 - $20,000",
      applicants: 12,
      postedDate: "5 days ago",
    },
    {
      id: 3,
      title: "Backend API Development",
      description:
        "Looking for a backend developer to create RESTful APIs for our financial services platform with secure authentication and data processing.",
      client: {
        name: "FinEdge",
        rating: 4.7,
        projects: 5,
      },
      skills: ["Node.js", "Express", "MongoDB", "Authentication", "API Design"],
      duration: "4 months",
      budget: "$10,000 - $15,000",
      applicants: 6,
      postedDate: "1 week ago",
    },
    {
      id: 4,
      title: "Data Visualization Dashboard",
      description:
        "Need a developer to create interactive data visualizations for our analytics platform using modern JavaScript libraries.",
      client: {
        name: "DataViz Co.",
        rating: 4.6,
        projects: 7,
      },
      skills: ["D3.js", "JavaScript", "Chart.js", "Data Processing", "Frontend"],
      duration: "2 months",
      budget: "$4,000 - $6,000",
      applicants: 4,
      postedDate: "3 days ago",
    },
    {
      id: 5,
      title: "AI-Powered Chatbot",
      description:
        "Looking for an AI developer to build a customer service chatbot with natural language processing capabilities.",
      client: {
        name: "ServiceAI",
        rating: 5.0,
        projects: 3,
      },
      skills: ["Python", "NLP", "Machine Learning", "API Integration"],
      duration: "5 months",
      budget: "$12,000 - $18,000",
      applicants: 9,
      postedDate: "Just now",
    },
  ]

  const filteredProjects = projects.filter(
    (project) =>
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.skills.some((skill) => skill.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  return (
    <div className="developer-theme min-h-screen bg-background">
      <Sidebar role="developer" />

      <div className="md:pl-64">
        <BackgroundPattern pattern="gradient-purple" className="min-h-screen">
          <header className="h-16 border-b flex items-center justify-between px-4 bg-background/80 backdrop-blur-sm">
            <h1 className="text-xl font-bold">Browse Projects</h1>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <ModeToggle />
              <Avatar>
                <AvatarImage src="/placeholder.svg" alt="@developer" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
            </div>
          </header>

          <main className="p-4 md:p-6">
            <div className="grid gap-6">
              <section>
                <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between mb-6">
                  <div className="relative w-full md:w-96">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search projects, skills, or keywords..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
                    <Select defaultValue="newest">
                      <SelectTrigger className="w-full sm:w-[180px]">
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="newest">Newest First</SelectItem>
                        <SelectItem value="budget-high">Budget: High to Low</SelectItem>
                        <SelectItem value="budget-low">Budget: Low to High</SelectItem>
                        <SelectItem value="duration">Duration: Short to Long</SelectItem>
                      </SelectContent>
                    </Select>

                    <Sheet>
                      <SheetTrigger asChild>
                        <Button variant="outline" className="w-full sm:w-auto">
                          <Filter className="h-4 w-4 mr-2" />
                          Filters
                        </Button>
                      </SheetTrigger>
                      <SheetContent>
                        <SheetHeader>
                          <SheetTitle>Filter Projects</SheetTitle>
                          <SheetDescription>Narrow down projects based on your preferences</SheetDescription>
                        </SheetHeader>
                        <div className="py-4 space-y-6">
                          <div className="space-y-4">
                            <h3 className="font-medium">Skills</h3>
                            <div className="space-y-2">
                              {["React", "Node.js", "JavaScript", "Python", "UI/UX", "Mobile", "API", "Database"].map(
                                (skill) => (
                                  <div key={skill} className="flex items-center space-x-2">
                                    <Checkbox id={`skill-${skill}`} />
                                    <Label htmlFor={`skill-${skill}`}>{skill}</Label>
                                  </div>
                                ),
                              )}
                            </div>
                          </div>

                          <div className="space-y-4">
                            <h3 className="font-medium">Project Duration</h3>
                            <div className="space-y-2">
                              {["Less than 1 month", "1-3 months", "3-6 months", "Over 6 months"].map((duration) => (
                                <div key={duration} className="flex items-center space-x-2">
                                  <Checkbox id={`duration-${duration}`} />
                                  <Label htmlFor={`duration-${duration}`}>{duration}</Label>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="space-y-4">
                            <h3 className="font-medium">Budget Range</h3>
                            <div className="space-y-2">
                              {["Under $5,000", "$5,000 - $10,000", "$10,000 - $20,000", "Over $20,000"].map(
                                (budget) => (
                                  <div key={budget} className="flex items-center space-x-2">
                                    <Checkbox id={`budget-${budget}`} />
                                    <Label htmlFor={`budget-${budget}`}>{budget}</Label>
                                  </div>
                                ),
                              )}
                            </div>
                          </div>

                          <div className="space-y-4">
                            <h3 className="font-medium">Client Rating</h3>
                            <div className="space-y-2">
                              {["4.5 & above", "4.0 & above", "3.5 & above", "Any rating"].map((rating) => (
                                <div key={rating} className="flex items-center space-x-2">
                                  <Checkbox id={`rating-${rating}`} />
                                  <Label htmlFor={`rating-${rating}`}>{rating}</Label>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="flex justify-end gap-4 pt-4">
                            <Button variant="outline">Reset</Button>
                            <Button>Apply Filters</Button>
                          </div>
                        </div>
                      </SheetContent>
                    </Sheet>
                  </div>
                </div>

                <div className="grid gap-4">
                  {filteredProjects.length > 0 ? (
                    filteredProjects.map((project) => (
                      <Card key={project.id}>
                        <CardContent className="p-6">
                          <div className="flex flex-col md:flex-row gap-6">
                            <div className="flex-1">
                              <h2 className="text-xl font-bold">{project.title}</h2>
                              <div className="flex items-center gap-2 mt-1">
                                <div className="text-sm text-muted-foreground">
                                  Posted by {project.client.name} • {project.postedDate}
                                </div>
                                <div className="flex items-center">
                                  <span className="text-yellow-500 mr-1">★</span>
                                  <span className="text-sm">{project.client.rating}</span>
                                </div>
                              </div>
                              <p className="mt-3">{project.description}</p>
                              <div className="flex flex-wrap gap-2 mt-4">
                                {project.skills.map((skill) => (
                                  <Badge key={skill} variant="outline">
                                    {skill}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div className="flex flex-col gap-4 md:w-64">
                              <div className="p-4 bg-muted rounded-lg">
                                <div className="grid grid-cols-2 gap-2 text-sm">
                                  <div className="text-muted-foreground">Budget:</div>
                                  <div className="font-medium text-right">{project.budget}</div>
                                  <div className="text-muted-foreground">Duration:</div>
                                  <div className="font-medium text-right">{project.duration}</div>
                                  <div className="text-muted-foreground">Applicants:</div>
                                  <div className="font-medium text-right">{project.applicants}</div>
                                </div>
                              </div>
                              <Button className="w-full">Apply Now</Button>
                              <Button variant="outline" className="w-full">
                                Save
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-12">
                      <h3 className="text-lg font-medium">No projects found</h3>
                      <p className="text-muted-foreground mt-2">Try adjusting your search or filters</p>
                    </div>
                  )}
                </div>
              </section>
            </div>
          </main>
        </BackgroundPattern>
      </div>
    </div>
  )
}
