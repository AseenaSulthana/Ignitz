"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { Card, CardContent } from "@/components/ui/card"
import { User, ChevronRight } from "lucide-react"
import { FireIcon } from "@/components/fire-icon"

export default function LandingPage() {
  const [typedText, setTypedText] = useState("")
  const fullText = "Connecting Developers and Entrepreneurs to Co-Create Innovations"

  useEffect(() => {
    if (typedText.length < fullText.length) {
      const timeout = setTimeout(() => {
        setTypedText(fullText.slice(0, typedText.length + 1))
      }, 100)

      return () => clearTimeout(timeout)
    }
  }, [typedText])

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-ignitz-violet/10 to-developer-purple/10"></div>
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-ignitz-violet/10 animate-pulse"></div>
        <div
          className="absolute top-3/4 left-2/3 w-48 h-48 rounded-full bg-developer-purple/10 animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/3 w-32 h-32 rounded-full bg-entrepreneur-blue/10 animate-pulse"
          style={{ animationDelay: "2s" }}
        ></div>
        <div
          className="absolute top-1/3 right-1/4 w-56 h-56 rounded-full bg-ignitz-violet/5 animate-pulse"
          style={{ animationDelay: "1.5s" }}
        ></div>
      </div>

      <header className="border-b relative z-10">
        <div className="container mx-auto flex justify-between items-center py-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white">
              <FireIcon className="h-5 w-5" />
            </div>
            <h1 className="text-2xl font-bold">Ignitz</h1>
          </div>
          <div className="flex items-center gap-4">
            <ModeToggle />
            <Link href="/login">
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-20 container mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-ignitz-violet to-developer-purple">
              Ignitz Platform
            </span>
          </h1>
          <div className="h-16 md:h-24 flex items-center justify-center">
            <p className="typing-animation text-xl md:text-2xl max-w-3xl mx-auto">{typedText}</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-12">
            <Link href="/login?role=developer">
              <Button size="lg" className="w-full sm:w-auto bg-developer-purple hover:bg-developer-purple/90">
                Login / Sign Up as Developer
              </Button>
            </Link>
            <Link href="/login?role=entrepreneur">
              <Button size="lg" className="w-full sm:w-auto bg-entrepreneur-blue hover:bg-entrepreneur-blue/90">
                Login / Sign Up as Entrepreneur
              </Button>
            </Link>
          </div>
        </section>

        <section className="py-16 bg-muted">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">How Ignitz Works</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-xl font-bold mb-2">For Developers</h3>
                  <p className="text-muted-foreground mb-4">
                    Showcase your skills, find exciting projects, and collaborate with innovative entrepreneurs.
                  </p>
                  <div className="flex justify-end">
                    <Link href="/login?role=developer">
                      <Button variant="ghost" className="text-developer-purple">
                        Learn More <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-xl font-bold mb-2">For Entrepreneurs</h3>
                  <p className="text-muted-foreground mb-4">
                    Find skilled developers, post your projects, and bring your innovative ideas to life.
                  </p>
                  <div className="flex justify-end">
                    <Link href="/login?role=entrepreneur">
                      <Button variant="ghost" className="text-entrepreneur-blue">
                        Learn More <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-xl font-bold mb-2">Ideathons & Pitching</h3>
                  <p className="text-muted-foreground mb-4">
                    Participate in or host ideathons to showcase innovation and connect with like-minded individuals.
                  </p>
                  <div className="flex justify-end">
                    <Link href="/ideathons">
                      <Button variant="ghost" className="text-primary">
                        Learn More <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-16 container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Success Stories</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="h-12 w-12 rounded-full bg-muted"></div>
                  <div>
                    <h3 className="font-bold">TechStartup & DevTeam</h3>
                    <p className="text-sm text-muted-foreground">AI-powered Healthcare Solution</p>
                  </div>
                </div>
                <p className="text-muted-foreground">
                  "Ignitz helped us find the perfect development team for our healthcare AI solution. The platform's
                  skill matching system connected us with developers who had exactly the expertise we needed."
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="h-12 w-12 rounded-full bg-muted"></div>
                  <div>
                    <h3 className="font-bold">Jane Developer</h3>
                    <p className="text-sm text-muted-foreground">Full-Stack Developer</p>
                  </div>
                </div>
                <p className="text-muted-foreground">
                  "As a developer, Ignitz has been a game-changer for my career. I've worked on innovative projects that
                  have enhanced my portfolio, and the skill endorsement system has helped me showcase my expertise."
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold mb-4">Why Ignitz</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Our Mission
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    How It Works
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Success Stories
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">For Developers</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Find Projects
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Skill Endorsements
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Ignitz Score
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">For Entrepreneurs</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Post Projects
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Find Developers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Host Ideathons
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Contact Us</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Support
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    FAQs
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t text-center text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} Ignitz Platform. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
