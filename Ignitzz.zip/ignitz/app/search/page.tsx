"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { ModeToggle } from "@/components/mode-toggle"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { BackgroundPattern } from "@/components/background-pattern"
import { Bell, Search, MapPin } from "lucide-react"

// Sample data for search results
const developers = [
  {
    id: 1,
    name: "Alex Johnson",
    role: "Full Stack Developer",
    location: "San Francisco, CA",
    skills: ["React", "Node.js", "MongoDB", "TypeScript"],
    rating: 4.9,
    hourlyRate: 75,
    availability: "Part-time",
    ignitzScore: 92,
  },
  {
    id: 2,
    name: "Sarah Williams",
    role: "UI/UX Designer & Frontend Developer",
    location: "New York, NY",
    skills: ["UI/UX", "Figma", "React", "CSS", "HTML"],
    rating: 4.8,
    hourlyRate: 85,
    availability: "Full-time",
    ignitzScore: 88,
  },
  {
    id: 3,
    name: "Michael Chen",
    role: "Backend Developer",
    location: "Austin, TX",
    skills: ["Python", "Django", "PostgreSQL", "AWS"],
    rating: 4.7,
    hourlyRate: 70,
    availability: "Contract",
    ignitzScore: 85,
  },
  {
    id: 4,
    name: "Emily Rodriguez",
    role: "Mobile Developer",
    location: "Seattle, WA",
    skills: ["React Native", "Swift", "Kotlin", "Firebase"],
    rating: 4.9,
    hourlyRate: 90,
    availability: "Full-time",
    ignitzScore: 94,
  },
  {
    id: 5,
    name: "David Kim",
    role: "Data Scientist & ML Engineer",
    location: "Boston, MA",
    skills: ["Python", "TensorFlow", "PyTorch", "Data Analysis"],
    rating: 4.6,
    hourlyRate: 95,
    availability: "Part-time",
    ignitzScore: 89,
  },
]

const projects = [
  {
    id: 1,
    title: "E-commerce Website Redesign",
    company: "RetailX",
    location: "Remote",
    skills: ["React", "UI/UX", "Responsive Design", "Tailwind CSS"],
    budget: "$5,000 - $8,000",
    duration: "3 months",
    postedDate: "2 days ago",
    domain: "Retail",
  },
  {
    id: 2,
    title: "Mobile App Development",
    company: "MediTech Inc.",
    location: "San Francisco, CA",
    skills: ["React Native", "Firebase", "API Integration", "Mobile UI"],
    budget: "$15,000 - $20,000",
    duration: "6 months",
    postedDate: "5 days ago",
    domain: "Healthcare",
  },
  {
    id: 3,
    title: "Backend API Development",
    company: "FinEdge",
    location: "New York, NY",
    skills: ["Node.js", "Express", "MongoDB", "Authentication", "API Design"],
    budget: "$10,000 - $15,000",
    duration: "4 months",
    postedDate: "1 week ago",
    domain: "Fintech",
  },
  {
    id: 4,
    title: "Data Visualization Dashboard",
    company: "DataViz Co.",
    location: "Remote",
    skills: ["D3.js", "JavaScript", "Chart.js", "Data Processing", "Frontend"],
    budget: "$4,000 - $6,000",
    duration: "2 months",
    postedDate: "3 days ago",
    domain: "Data Analytics",
  },
  {
    id: 5,
    title: "AI-Powered Chatbot",
    company: "ServiceAI",
    location: "Boston, MA",
    skills: ["Python", "NLP", "Machine Learning", "API Integration"],
    budget: "$12,000 - $18,000",
    duration: "5 months",
    postedDate: "Just now",
    domain: "Artificial Intelligence",
  },
]

// Available filter options
const domains = ["Retail", "Healthcare", "Fintech", "Data Analytics", "Artificial Intelligence", "Education", "Gaming"]
const locations = ["Remote", "San Francisco, CA", "New York, NY", "Austin, TX", "Seattle, WA", "Boston, MA"]
const skills = [
  "React",
  "Node.js",
  "Python",
  "JavaScript",
  "TypeScript",
  "UI/UX",
  "MongoDB",
  "PostgreSQL",
  "AWS",
  "Firebase",
  "Machine Learning",
  "Data Analysis",
]

export default function SearchPage() {
  const [searchType, setSearchType] = useState<"developers" | "projects">("developers")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedDomains, setSelectedDomains] = useState<string[]>([])
  const [selectedLocations, setSelectedLocations] = useState<string[]>([])
  const [selectedSkills, setSelectedSkills] = useState<string[]>([])
  const [priceRange, setPriceRange] = useState([0, 100])
  const [sortBy, setSortBy] = useState("relevance")

  // Filter function for developers
  const filteredDevelopers = developers.filter((developer) => {
    // Search query filter
    if (
      searchQuery &&
      !developer.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !developer.role.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !developer.skills.some((skill) => skill.toLowerCase().includes(searchQuery.toLowerCase()))
    ) {
      return false
    }

    // Location filter
    if (selectedLocations.length > 0 && !selectedLocations.includes(developer.location)) {
      return false
    }

    // Skills filter
    if (selectedSkills.length > 0 && !selectedSkills.some((skill) => developer.skills.includes(skill))) {
      return false
    }

    // Price range filter
    if (developer.hourlyRate < priceRange[0] || developer.hourlyRate > priceRange[1]) {
      return false
    }

    return true
  })

  // Filter function for projects
  const filteredProjects = projects.filter((project) => {
    // Search query filter
    if (
      searchQuery &&
      !project.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !project.company.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !project.skills.some((skill) => skill.toLowerCase().includes(searchQuery.toLowerCase()))
    ) {
      return false
    }

    // Domain filter
    if (selectedDomains.length > 0 && !selectedDomains.includes(project.domain)) {
      return false
    }

    // Location filter
    if (selectedLocations.length > 0 && !selectedLocations.includes(project.location)) {
      return false
    }

    // Skills filter
    if (selectedSkills.length > 0 && !selectedSkills.some((skill) => project.skills.includes(skill))) {
      return false
    }

    return true
  })

  // Toggle domain selection
  const toggleDomain = (domain: string) => {
    if (selectedDomains.includes(domain)) {
      setSelectedDomains(selectedDomains.filter((d) => d !== domain))
    } else {
      setSelectedDomains([...selectedDomains, domain])
    }
  }

  // Toggle location selection
  const toggleLocation = (location: string) => {
    if (selectedLocations.includes(location)) {
      setSelectedLocations(selectedLocations.filter((l) => l !== location))
    } else {
      setSelectedLocations([...selectedLocations, location])
    }
  }

  // Toggle skill selection
  const toggleSkill = (skill: string) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter((s) => s !== skill))
    } else {
      setSelectedSkills([...selectedSkills, skill])
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar role="developer" />

      <div className="md:pl-64">
        <BackgroundPattern pattern="dots" className="min-h-screen">
          <header className="h-16 border-b flex items-center justify-between px-4 bg-background/80 backdrop-blur-sm">
            <h1 className="text-xl font-bold">Search</h1>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <ModeToggle />
              <Avatar>
                <AvatarImage src="/placeholder.svg" alt="@user" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
            </div>
          </header>

          <main className="p-4 md:p-6">
            <div className="grid gap-6">
              <section>
                <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between mb-6">
                  <div className="flex gap-4 w-full md:w-auto">
                    <Select
                      value={searchType}
                      onValueChange={(value: "developers" | "projects") => setSearchType(value)}
                    >
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Search for..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="developers">Developers</SelectItem>
                        <SelectItem value="projects">Projects</SelectItem>
                      </SelectContent>
                    </Select>

                    <div className="relative flex-1 min-w-[200px]">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="search"
                        placeholder={`Search ${searchType}...`}
                        className="pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="flex gap-4 w-full md:w-auto">
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="relevance">Relevance</SelectItem>
                        <SelectItem value="rating-high">Rating: High to Low</SelectItem>
                        <SelectItem value="rating-low">Rating: Low to High</SelectItem>
                        {searchType === "developers" ? (
                          <>
                            <SelectItem value="rate-high">Rate: High to Low</SelectItem>
                            <SelectItem value="rate-low">Rate: Low to High</SelectItem>
                            <SelectItem value="score-high">Ignitz Score: High to Low</SelectItem>
                          </>
                        ) : (
                          <>
                            <SelectItem value="budget-high">Budget: High to Low</SelectItem>
                            <SelectItem value="budget-low">Budget: Low to High</SelectItem>
                            <SelectItem value="newest">Newest First</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-[300px_1fr] gap-6">
                  {/* Filters */}
                  <div className="search-filters">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-lg font-medium">Filters</h2>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedDomains([])
                          setSelectedLocations([])
                          setSelectedSkills([])
                          setPriceRange([0, 100])
                        }}
                      >
                        Reset
                      </Button>
                    </div>

                    <Accordion type="multiple" className="space-y-2">
                      {searchType === "projects" && (
                        <AccordionItem value="domains">
                          <AccordionTrigger className="py-2">Domains</AccordionTrigger>
                          <AccordionContent>
                            <div className="space-y-2">
                              {domains.map((domain) => (
                                <div key={domain} className="flex items-center space-x-2">
                                  <Checkbox
                                    id={`domain-${domain}`}
                                    checked={selectedDomains.includes(domain)}
                                    onCheckedChange={() => toggleDomain(domain)}
                                  />
                                  <Label htmlFor={`domain-${domain}`}>{domain}</Label>
                                </div>
                              ))}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      )}

                      <AccordionItem value="locations">
                        <AccordionTrigger className="py-2">Locations</AccordionTrigger>
                        <AccordionContent>
                          <div className="space-y-2">
                            {locations.map((location) => (
                              <div key={location} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`location-${location}`}
                                  checked={selectedLocations.includes(location)}
                                  onCheckedChange={() => toggleLocation(location)}
                                />
                                <Label htmlFor={`location-${location}`}>{location}</Label>
                              </div>
                            ))}
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="skills">
                        <AccordionTrigger className="py-2">Skills</AccordionTrigger>
                        <AccordionContent>
                          <div className="space-y-2">
                            {skills.map((skill) => (
                              <div key={skill} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`skill-${skill}`}
                                  checked={selectedSkills.includes(skill)}
                                  onCheckedChange={() => toggleSkill(skill)}
                                />
                                <Label htmlFor={`skill-${skill}`}>{skill}</Label>
                              </div>
                            ))}
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {searchType === "developers" && (
                        <AccordionItem value="price-range">
                          <AccordionTrigger className="py-2">Hourly Rate ($)</AccordionTrigger>
                          <AccordionContent>
                            <div className="space-y-4">
                              <Slider value={priceRange} min={0} max={200} step={5} onValueChange={setPriceRange} />
                              <div className="flex items-center justify-between">
                                <span>${priceRange[0]}</span>
                                <span>${priceRange[1]}</span>
                              </div>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      )}
                    </Accordion>

                    <div className="mt-6">
                      <h3 className="text-sm font-medium mb-2">Active Filters</h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedDomains.map((domain) => (
                          <Badge
                            key={domain}
                            variant="secondary"
                            className="cursor-pointer"
                            onClick={() => toggleDomain(domain)}
                          >
                            {domain} ×
                          </Badge>
                        ))}
                        {selectedLocations.map((location) => (
                          <Badge
                            key={location}
                            variant="secondary"
                            className="cursor-pointer"
                            onClick={() => toggleLocation(location)}
                          >
                            {location} ×
                          </Badge>
                        ))}
                        {selectedSkills.map((skill) => (
                          <Badge
                            key={skill}
                            variant="secondary"
                            className="cursor-pointer"
                            onClick={() => toggleSkill(skill)}
                          >
                            {skill} ×
                          </Badge>
                        ))}
                        {priceRange[0] > 0 || priceRange[1] < 100 ? (
                          <Badge variant="secondary" className="cursor-pointer" onClick={() => setPriceRange([0, 100])}>
                            ${priceRange[0]} - ${priceRange[1]} ×
                          </Badge>
                        ) : null}
                      </div>
                    </div>
                  </div>

                  {/* Search Results */}
                  <div className="search-results">
                    <h2 className="text-lg font-medium mb-4">
                      {searchType === "developers"
                        ? `${filteredDevelopers.length} Developers Found`
                        : `${filteredProjects.length} Projects Found`}
                    </h2>

                    {searchType === "developers" ? (
                      filteredDevelopers.length > 0 ? (
                        filteredDevelopers.map((developer) => (
                          <Card key={developer.id} className="mb-4">
                            <CardContent className="p-6">
                              <div className="flex flex-col md:flex-row gap-4">
                                <div className="flex items-start gap-4">
                                  <Avatar className="h-12 w-12">
                                    <AvatarFallback>
                                      {developer.name
                                        .split(" ")
                                        .map((n) => n[0])
                                        .join("")}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <h3 className="font-bold">{developer.name}</h3>
                                    <p className="text-muted-foreground">{developer.role}</p>
                                    <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground">
                                      <MapPin className="h-3 w-3" />
                                      <span>{developer.location}</span>
                                    </div>
                                    <div className="flex flex-wrap gap-1 mt-2">
                                      {developer.skills.map((skill) => (
                                        <Badge key={skill} variant="outline" className="text-xs">
                                          {skill}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                                <div className="md:ml-auto text-right">
                                  <div className="flex items-center justify-end gap-1">
                                    <span className="font-bold">{developer.rating}</span>
                                    <span className="text-yellow-500">★</span>
                                  </div>
                                  <div className="text-sm font-medium">${developer.hourlyRate}/hr</div>
                                  <div className="text-xs text-muted-foreground">{developer.availability}</div>
                                  <div className="mt-2">
                                    <Badge variant="secondary">Ignitz Score: {developer.ignitzScore}</Badge>
                                  </div>
                                  <Button size="sm" className="mt-2">
                                    View Profile
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                      ) : (
                        <div className="text-center py-12">
                          <p className="text-muted-foreground">No developers found matching your criteria.</p>
                        </div>
                      )
                    ) : filteredProjects.length > 0 ? (
                      filteredProjects.map((project) => (
                        <Card key={project.id} className="mb-4">
                          <CardContent className="p-6">
                            <div className="flex flex-col md:flex-row gap-4">
                              <div>
                                <h3 className="font-bold">{project.title}</h3>
                                <p className="text-muted-foreground">{project.company}</p>
                                <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground">
                                  <MapPin className="h-3 w-3" />
                                  <span>{project.location}</span>
                                </div>
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {project.skills.map((skill) => (
                                    <Badge key={skill} variant="outline" className="text-xs">
                                      {skill}
                                    </Badge>
                                  ))}
                                </div>
                                <Badge className="mt-2" variant="secondary">
                                  {project.domain}
                                </Badge>
                              </div>
                              <div className="md:ml-auto text-right">
                                <div className="font-medium">{project.budget}</div>
                                <div className="text-sm text-muted-foreground">Duration: {project.duration}</div>
                                <div className="text-xs text-muted-foreground">Posted: {project.postedDate}</div>
                                <Button size="sm" className="mt-4">
                                  View Details
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    ) : (
                      <div className="text-center py-12">
                        <p className="text-muted-foreground">No projects found matching your criteria.</p>
                      </div>
                    )}
                  </div>
                </div>
              </section>
            </div>
          </main>
        </BackgroundPattern>
      </div>
    </div>
  )
}
