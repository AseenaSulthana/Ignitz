"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { BackgroundPattern } from "@/components/background-pattern"
import { getUserFromLocalStorage } from "@/lib/auth"
import { Send, ArrowLeft } from "lucide-react"

export default function MessagesPage() {
  const [user, setUser] = useState<any>(null)
  const [conversations, setConversations] = useState([])
  const [messages, setMessages] = useState([])
  const [activeConversation, setActiveConversation] = useState<any>(null)
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const userData = getUserFromLocalStorage()
    if (userData) {
      setUser(userData)
    }

    // Fetch conversations
    fetchConversations()
  }, [])

  useEffect(() => {
    if (activeConversation) {
      fetchMessages(activeConversation.conversation_with)
    }
  }, [activeConversation])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const fetchConversations = async () => {
    try {
      setLoading(true)
      const res = await fetch("/api/messages")
      const data = await res.json()
      setConversations(data)
    } catch (error) {
      console.error("Error fetching conversations:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchMessages = async (userId: number) => {
    try {
      setLoading(true)
      const res = await fetch(`/api/messages?with=${userId}`)
      const data = await res.json()
      setMessages(data)
    } catch (error) {
      console.error("Error fetching messages:", error)
    } finally {
      setLoading(false)
    }
  }

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim() || !activeConversation) return

    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          receiverId: activeConversation.conversation_with,
          content: newMessage,
        }),
      })

      const data = await res.json()

      if (data.success) {
        // Add the new message to the list
        setMessages([
          ...messages,
          {
            id: data.message.id,
            sender_id: user.id,
            receiver_id: activeConversation.conversation_with,
            content: newMessage,
            created_at: new Date().toISOString(),
            sender_first_name: user.firstName,
            sender_last_name: user.lastName,
          },
        ])

        // Clear the input
        setNewMessage("")
      }
    } catch (error) {
      console.error("Error sending message:", error)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50 relative">
      <BackgroundPattern className="absolute inset-0 z-0 opacity-10" />

      <div className="container mx-auto p-4 relative z-10">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden" style={{ height: "calc(100vh - 2rem)" }}>
          <div className="grid grid-cols-1 md:grid-cols-3 h-full">
            {/* Conversations list */}
            <div className={`border-r ${activeConversation ? "hidden md:block" : "block"}`}>
              <div className="p-4 border-b">
                <h1 className="text-xl font-bold">Messages</h1>
              </div>

              <div className="overflow-y-auto" style={{ height: "calc(100% - 4rem)" }}>
                {loading && !activeConversation ? (
                  <div className="p-4 text-center">Loading conversations...</div>
                ) : conversations.length === 0 ? (
                  <div className="p-4 text-center text-gray-500">No conversations yet</div>
                ) : (
                  conversations.map((convo: any) => (
                    <div
                      key={convo.conversation_with}
                      className="p-4 border-b hover:bg-gray-50 cursor-pointer"
                      onClick={() => setActiveConversation(convo)}
                    >
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 font-bold">
                          {convo.first_name[0]}
                          {convo.last_name[0]}
                        </div>
                        <div className="ml-3 flex-1">
                          <div className="flex justify-between">
                            <p className="font-medium">
                              {convo.first_name} {convo.last_name}
                            </p>
                            <p className="text-xs text-gray-500">
                              {new Date(convo.last_message_time).toLocaleDateString()}
                            </p>
                          </div>
                          <p className="text-sm text-gray-500">{convo.role}</p>
                        </div>
                      </div>
                      {convo.unread_count > 0 && (
                        <div className="mt-1 flex justify-end">
                          <span className="px-2 py-1 bg-blue-500 text-white text-xs rounded-full">
                            {convo.unread_count}
                          </span>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Messages */}
            <div className={`col-span-2 flex flex-col ${activeConversation ? "block" : "hidden md:block"}`}>
              {activeConversation ? (
                <>
                  <div className="p-4 border-b flex items-center">
                    <button className="md:hidden mr-2" onClick={() => setActiveConversation(null)}>
                      <ArrowLeft className="h-5 w-5" />
                    </button>
                    <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 font-bold">
                      {activeConversation.first_name[0]}
                      {activeConversation.last_name[0]}
                    </div>
                    <div className="ml-3">
                      <p className="font-medium">
                        {activeConversation.first_name} {activeConversation.last_name}
                      </p>
                      <p className="text-sm text-gray-500">{activeConversation.role}</p>
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {loading ? (
                      <div className="text-center">Loading messages...</div>
                    ) : messages.length === 0 ? (
                      <div className="text-center text-gray-500">No messages yet. Start the conversation!</div>
                    ) : (
                      messages.map((msg: any) => {
                        const isMe = msg.sender_id === user.id
                        return (
                          <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                            <div
                              className={`max-w-[70%] rounded-lg p-3 ${
                                isMe ? "bg-blue-500 text-white" : "bg-gray-100"
                              }`}
                            >
                              <p>{msg.content}</p>
                              <p className={`text-xs mt-1 ${isMe ? "text-blue-100" : "text-gray-500"}`}>
                                {new Date(msg.created_at).toLocaleTimeString([], {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </p>
                            </div>
                          </div>
                        )
                      })
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  <div className="p-4 border-t">
                    <form onSubmit={sendMessage} className="flex">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type a message..."
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 bg-blue-500 text-white rounded-r-md hover:bg-blue-600 transition-colors"
                      >
                        <Send className="h-5 w-5" />
                      </button>
                    </form>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <h2 className="text-xl font-medium mb-2">Select a conversation</h2>
                    <p className="text-gray-500">Choose a conversation from the list to start messaging</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
