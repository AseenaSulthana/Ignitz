"use client"

import { Sidebar } from "@/components/sidebar"
import { ModeToggle } from "@/components/mode-toggle"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { BackgroundPattern } from "@/components/background-pattern"
import { Bell } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

// FAQ data
const developerFaqs = [
  {
    question: "How do I get started as a developer on Ignitz?",
    answer:
      "To get started, create an account as a developer, complete your profile with your skills and experience, and browse available projects. You can also set up notifications for projects that match your skills.",
  },
  {
    question: "How does the Ignitz Score work?",
    answer:
      "The Ignitz Score is a measure of your reputation and activity on the platform. It's calculated based on project completions, client reviews, skill endorsements, and platform engagement. A higher score increases your visibility to entrepreneurs.",
  },
  {
    question: "How do skill endorsements work?",
    answer:
      "Skill endorsements are validations of your expertise from other users who have worked with you. After completing a project, collaborators can endorse your skills, which adds credibility to your profile.",
  },
  {
    question: "How do I apply for projects?",
    answer:
      "Browse the projects section, filter by your skills or interests, and click on projects you're interested in. You can then submit a proposal that includes your approach, timeline, and bid amount.",
  },
  {
    question: "How do payments work?",
    answer:
      "Payments are handled securely through our platform. For fixed-price projects, funds are held in escrow and released upon milestone completion. For hourly projects, you'll track your time through our system, and payments are processed weekly.",
  },
]

const entrepreneurFaqs = [
  {
    question: "How do I post a project on Ignitz?",
    answer:
      "After creating an entrepreneur account, click on 'Post New Project' from your dashboard. Fill in the project details, including description, required skills, budget, and timeline. Once submitted, your project will be visible to relevant developers.",
  },
  {
    question: "How do I find the right developers for my project?",
    answer:
      "You can browse developer profiles using our search filters for skills, experience level, and Ignitz Score. Alternatively, post your project and wait for developers to submit proposals. Our matching algorithm will also recommend suitable developers for your project.",
  },
  {
    question: "What is the typical timeline for finding a developer?",
    answer:
      "Most projects receive their first proposals within 24-48 hours. The time to find the right match depends on your project's complexity and requirements. On average, entrepreneurs find suitable developers within a week.",
  },
  {
    question: "How do I ensure the quality of work?",
    answer:
      "Review developer profiles, including their Ignitz Score, past projects, and skill endorsements. Set clear milestones and deliverables in your project agreement. Our platform also provides tools for regular check-ins and progress tracking.",
  },
  {
    question: "What happens if I'm not satisfied with the work?",
    answer:
      "We encourage open communication to resolve issues. If problems persist, you can request mediation through our support team. For milestone-based projects, payment is only released when you approve the completed work.",
  },
]

const platformFaqs = [
  {
    question: "What fees does Ignitz charge?",
    answer:
      "Ignitz charges a 10% service fee on project payments. This fee covers platform maintenance, payment processing, and support services. There are no membership fees or charges for posting projects or submitting proposals.",
  },
  {
    question: "How does Ignitz ensure security and privacy?",
    answer:
      "We use industry-standard encryption for all data and transactions. Personal information is only shared with explicit consent. Our platform includes secure messaging and file sharing tools to protect your intellectual property.",
  },
  {
    question: "What support does Ignitz provide?",
    answer:
      "We offer 24/7 customer support via chat and email. Our help center contains comprehensive guides and tutorials. For premium users, we also provide dedicated account managers and priority support.",
  },
  {
    question: "Can I use Ignitz for team projects?",
    answer:
      "Yes, Ignitz supports team collaboration. Entrepreneurs can hire multiple developers for a project, and developers can form teams to tackle larger projects. Our platform includes tools for team communication and project management.",
  },
  {
    question: "How do ideathons work on Ignitz?",
    answer:
      "Ideathons are collaborative events where entrepreneurs and developers come together to solve challenges. You can participate in existing ideathons or host your own. Winners often receive prizes and opportunities for further project development.",
  },
]

export default function FaqPage() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar role="developer" />

      <div className="md:pl-64">
        <BackgroundPattern pattern="dots" className="min-h-screen">
          <header className="h-16 border-b flex items-center justify-between px-4 bg-background/80 backdrop-blur-sm">
            <h1 className="text-xl font-bold">Frequently Asked Questions</h1>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <ModeToggle />
              <Avatar>
                <AvatarImage src="/placeholder.svg" alt="@user" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
            </div>
          </header>

          <main className="p-4 md:p-6">
            <div className="max-w-4xl mx-auto">
              <section className="mb-8">
                <h2 className="text-3xl font-bold mb-2">Frequently Asked Questions</h2>
                <p className="text-muted-foreground mb-8">
                  Find answers to common questions about using the Ignitz platform.
                </p>

                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-4">For Developers</h3>
                  <Accordion type="single" collapsible className="w-full">
                    {developerFaqs.map((faq, index) => (
                      <AccordionItem key={index} value={`developer-item-${index}`}>
                        <AccordionTrigger>{faq.question}</AccordionTrigger>
                        <AccordionContent>{faq.answer}</AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </div>

                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-4">For Entrepreneurs</h3>
                  <Accordion type="single" collapsible className="w-full">
                    {entrepreneurFaqs.map((faq, index) => (
                      <AccordionItem key={index} value={`entrepreneur-item-${index}`}>
                        <AccordionTrigger>{faq.question}</AccordionTrigger>
                        <AccordionContent>{faq.answer}</AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </div>

                <div>
                  <h3 className="text-xl font-bold mb-4">Platform & General</h3>
                  <Accordion type="single" collapsible className="w-full">
                    {platformFaqs.map((faq, index) => (
                      <AccordionItem key={index} value={`platform-item-${index}`}>
                        <AccordionTrigger>{faq.question}</AccordionTrigger>
                        <AccordionContent>{faq.answer}</AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </div>
              </section>

              <section className="mt-12 p-6 bg-muted rounded-lg text-center">
                <h3 className="text-xl font-bold mb-2">Still have questions?</h3>
                <p className="mb-4">Our support team is here to help you with any other questions you might have.</p>
                <Button>Contact Support</Button>
              </section>
            </div>
          </main>
        </BackgroundPattern>
      </div>
    </div>\
