import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { jwtVerify, decodeJwt } from "jose"

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key")

// Paths that don't require authentication
const publicPaths = ["/", "/login", "/api/auth/login", "/api/auth/register"]

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname

  // Check if the path is public
  if (publicPaths.some((publicPath) => path === publicPath || path.startsWith("/api/auth/"))) {
    return NextResponse.next()
  }

  // Check for auth token
  const token = request.cookies.get("auth_token")?.value

  if (!token) {
    return NextResponse.redirect(new URL("/login", request.url))
  }

  try {
    // Verify token
    await jwtVerify(token, JWT_SECRET)

    // For API routes, continue
    if (path.startsWith("/api/")) {
      return NextResponse.next()
    }

    // For developer routes, check if user is a developer
    if (path.startsWith("/developer/")) {
      const payload = decodeJwt(token) as any
      if (payload.role !== "developer") {
        return NextResponse.redirect(new URL("/login", request.url))
      }
    }

    // For entrepreneur routes, check if user is an entrepreneur
    if (path.startsWith("/entrepreneur/")) {
      const payload = decodeJwt(token) as any
      if (payload.role !== "entrepreneur") {
        return NextResponse.redirect(new URL("/login", request.url))
      }
    }

    return NextResponse.next()
  } catch (error) {
    // Token is invalid
    return NextResponse.redirect(new URL("/login", request.url))
  }
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
}
